<template>
  <div class="not-main">
    404
  </div>
</template>
