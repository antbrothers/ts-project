export const LOGIN = 'LOGIN'
export const MENU = 'MENU'
