export const WELCOME = 'WELCOME'
