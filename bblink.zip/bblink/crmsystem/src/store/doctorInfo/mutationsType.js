export const DOCTORINFO = 'DOCTORINFO'
