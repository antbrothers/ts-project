export const LOADING = 'LOADING'
