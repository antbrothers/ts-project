export const HIGHTDAN = 'HIGHTDAN'
export const USERDATA = 'USERDATA'
