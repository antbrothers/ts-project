export const ADDCOURSE = 'ADDCOURSE'
export const SAVECOURSE = 'SAVECOURSE'
