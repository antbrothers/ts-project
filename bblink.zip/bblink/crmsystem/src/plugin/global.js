export default {
  install (Vue) {
    window.$global_this = new Vue()
  }
}
