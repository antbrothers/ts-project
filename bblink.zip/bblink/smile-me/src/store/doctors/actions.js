import * as types from './mutationType'
import {fetch} from '../../../src/common/fetch'
/**
 * 获取门诊医生列表信息
 * @param {*} param0
 * @param {*} options
 */
export const getMenZhenDoctorList = ({commit}, options) => {
  return fetch({
    url: '/api/inquiry/outpatient/getDoctors',
    method: 'get',
    params: {
      code: options.code,
      page: options.page,
      size: options.size,
      version: options.version
    },
    success: function (res) {
      if (res.data.code === '0000') {
        commit(types.MDL, res.data.data)
        commit(types.MZTOTAL, res.data.totalCount)
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}

/**
 * 获取服务医生列表信息
 * @param {*} param0
 * @param {*} options
 */
export const getServiceDoctorList = ({commit}, options) => {
  return fetch({
    url: '/api/inquiry/hos/pkgcard/doctors/v1.3',
    method: 'get',
    params: {
      hosId: options.hosId,
      page: options.page,
      size: options.size
    },
    success: function (res) {
      if (res.data.code === '0000') {
        commit(types.SD, res.data.data.list)
        commit(types.TOTAL, res.data.data.totalCount)
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}

/**
 * 清除List
 * @param {*} param0
 */
export const clear = ({commit}) => {
  return commit(types.CLEAR)
}
/**
 * 清除门诊List
 * @param {*} param0
 */
export const mzclear = ({commit}) => {
  return commit(types.MZCLEAR)
}
