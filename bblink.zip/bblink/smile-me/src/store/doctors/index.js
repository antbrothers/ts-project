import * as types from './mutationType'
import * as actions from './actions'
const state = () => ({
  menZhenDoctorsList: [],
  totalCount: 0,
  mzTotalCount: 0,
  doctorList: [],
  isShow: true,
  menZhenShow: true,
  mzlength: 0,
  dlength: 0
})
const mutations = {
  [types.SD] (state, result) {
    result.forEach((v, k) => {
      state.doctorList.push(v)
    })
    state.dlength = state.doctorList.length
    if (state.doctorList.length === 0) {
      state.isShow = false
    }
  },
  [types.CLEAR] (state) {
    state.doctorList = []
  },
  [types.MZCLEAR] (state) {
    state.menZhenDoctorsList = []
  },
  [types.MDL] (state, result) {
    result.forEach((v, k) => {
      state.menZhenDoctorsList.push(v)
    })
    state.mzlength = state.menZhenDoctorsList.length
    if (state.menZhenDoctorsList.length === 0) {
      state.menZhenShow = false
    }
  },
  [types.TOTAL] (state, result) {
    state.totalCount = result
  },
  [types.MZTOTAL] (state, result) {
    state.mzTotalCount = result
  }
}
export default {
  actions,
  state,
  mutations
}
