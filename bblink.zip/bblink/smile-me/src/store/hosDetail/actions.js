import * as types from './mutationType'
import { fetch } from '../../../src/common/fetch'
/**
 * 获取医院详情
 * @param {*} param0
 * @param {*} options
 */
export const getHosDetail = ({commit}, options) => {
  return fetch({
    url: '/api/inquiry/home/hosDetail',
    method: 'get',
    params: {
      hosId: options.hosId || '',
      schoolId: options.schoolId || ''
    },
    success: function (res) {
      if (res.data.code === '0000') {
        options.vue.id = res.data.data.hosId
        commit(types.HOSDETAIL, res.data.data)
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}
