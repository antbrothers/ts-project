import * as types from './mutationType'
import * as actions from './actions'
const state = () => ({
  dt: {},
  tel: []
})
const mutations = {
  [types.HOSDETAIL] (state, result) {
    state.tel = []
    state.dt = result
    state.tel = result.tel.split(',')
  }
}
export default {
  actions,
  state,
  mutations
}
