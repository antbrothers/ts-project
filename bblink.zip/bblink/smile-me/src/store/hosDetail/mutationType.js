export const HOSDETAIL = 'HOSDETAIL'
