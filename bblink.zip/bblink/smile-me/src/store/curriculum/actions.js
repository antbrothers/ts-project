import * as types from './mutationType'
import { fetch } from '../../../src/common/fetch'

export const getScheduleDetail = ({commit}, options) => {
  return fetch({
    url: '/babyapi/api/school/v1.3/scheduleDetail',
    method: 'get',
    params: {
      scheduleId: options.scheduleId
    },
    success: function (res) {
      commit(types.SCHEDULEDETAIL, res.data.data)
      console.log(res)
    },
    fail: function (err) {
      console.log(err)
    }
  })
}
