import * as types from './mutationType'
import * as actions from './actions'
const state = () => ({
  data: {}
})
const mutations = {
  [types.SCHEDULEDETAIL] (state, result) {
    state.data = result
  }
}

export default {
  state,
  actions,
  mutations
}
