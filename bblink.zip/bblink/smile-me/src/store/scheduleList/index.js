import * as types from './mutationType'
import * as actions from './actions'
const state = () => ({
  schedule: [],
  totalcount: 0
})
const mutations = {
  [types.SCHEDULELIST] (state, result) {
    result.forEach((v, k) => {
      state.schedule.push(v)
    })
  },
  [types.TOTALCOUNT] (state, result) {
    state.totalcount = result
  }
}
export default {
  state,
  actions,
  mutations
}
