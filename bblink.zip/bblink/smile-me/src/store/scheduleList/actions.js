import * as types from './mutationType'
import { fetch } from '../../common/fetch'

export const getScheduleList = ({commit}, options) => {
  return fetch({
    url: '/babyapi/api/school/v1.3/scheduleList',
    method: 'get',
    params: {
      schoolId: options.schoolId,
      page: options.page ? options.page : 1,
      size: options.size ? options.size : 1
    },
    success: function (res) {
      commit(types.SCHEDULELIST, res.data.data.list)
      commit(types.TOTALCOUNT, res.data.data.totalCount)
    },
    fail: function (err) {
      console.log(err)
    }
  })
}
