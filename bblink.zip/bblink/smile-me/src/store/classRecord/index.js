import * as types from './mutationType'
import * as actions from './actions'
const state = () => ({
  record: []
})
const mutations = {
  [types.CLASSRECORD] (state, result) {
    state.record = result
  }
}

export default {
  state,
  actions,
  mutations
}
