import * as types from './mutationType'
import { fetch } from '../../../src/common/fetch'

export const getClassRecord = ({commit}, options) => {
  return fetch({
    url: '/babyapi/api/school/v1.3/myScheduleList',
    method: 'get',
    params: {
      schoolId: options.schoolId
    },
    success: function (res) {
      commit(types.CLASSRECORD, res.data.data.list)
      console.log(res)
    },
    fail: function (err) {
      console.log(err)
    }
  })
}
