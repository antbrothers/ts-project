import * as types from './mutationType'
import { fetch } from '../../common/fetch'

/**
 * 获取医院门诊列表
 * @param {} param0
 * @param {*} options
 */
export const getOutpatient = ({commit}, options) => {
  return fetch({
    url: '/api/inquiry/outpatientInfo/getOutpatientInfos/v1.3',
    method: 'get',
    params: {
      hosId: options.hosId,
      page: options.page,
      size: options.size
    },
    success: function (res) {
      if (res.data.code === '0000') {
        commit(types.OUTPATIENT, {result: res.data.data, page: options.page})
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}
