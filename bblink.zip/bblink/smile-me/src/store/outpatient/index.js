import * as types from './mutationType'
import * as actions from './actions'
const state = () => ({
  dt: {
    currentPage: 0,
    list: [],
    pageCount: 0,
    pageSize: 0,
    totalCount: 0
  }
})
const mutations = {
  [types.OUTPATIENT] (state, res) {
    state.dt.currentPage = res.result.currentPage
    state.dt.pageCount = res.result.pageCount
    state.dt.pageSize = res.result.pageSize
    state.dt.totalCount = res.result.totalCount
    if (res.page === 1) {
      state.dt.list = res.result.list
    } else {
      res.result.list.map(function (currentValue, index, arr) {
        state.dt.list.push(currentValue)
      })
    }
  }
}
export default {
  actions,
  state,
  mutations
}
