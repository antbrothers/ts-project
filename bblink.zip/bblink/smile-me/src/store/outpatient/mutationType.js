export const OUTPATIENT = 'OUTPATIENT'
