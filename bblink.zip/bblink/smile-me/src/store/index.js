import Vue from 'vue'
import Vuex from 'vuex'
import loading from './loadIng'
import welcome from './welcome/index'
import hosDetail from './hosDetail'
import doctors from './doctors'
import outPatient from './outpatient'
import hospitalHome from './hospitalHome'
import scheduleList from './scheduleList'
import classRecord from './classRecord'
import goodCourse from './goodCourse'
import curriculum from './curriculum'
import sweetown from './sweetown'
import mine from './mine'
Vue.use(Vuex)
const debug = process.env.NODE_ENV !== 'production'
export default new Vuex.Store({
  modules: {
    loading,
    welcome,
    hosDetail,
    doctors,
    outPatient,
    hospitalHome,
    scheduleList,
    classRecord,
    goodCourse,
    curriculum,
    sweetown,
    mine
  },
  strict: debug
})
