import * as types from './mutationType'
import {fetch} from '../../../src/common/fetch'

/**
 * 获取精选好课
 * @param {*} param0
 * @param {*} options
 */
export const getCourseExportList = ({commit}, options) => {
  return fetch({
    url: '/api/school/live/course/expert/list',
    method: 'get',
    params: {
      hosId: options.hosId,
      pageNo: options.page,
      pageSize: options.size
    },
    success: function (res) {
      if (res.data.code === '0000') {
        commit(types.GOODCOURSE, {result: res.data.data, page: options.page})
        options._this.$refs.loadmore.onBottomLoaded()
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}
