import * as types from './mutationType'
import * as actions from './actions'
const state = () => ({
  courseList: {
    currentPage: 0,
    list: [],
    pageCount: 0,
    pageSize: 0,
    totalCount: 0
  }
})
const mutations = {
  [types.GOODCOURSE] (state, res) {
    // state.courseList = result
    state.courseList.currentPage = res.result.currentPage
    state.courseList.pageCount = res.result.pageCount
    state.courseList.pageSize = res.result.pageSize
    state.courseList.totalCount = res.result.totalCount
    if (res.page === 1) {
      state.courseList.list = res.result.list
    } else {
      res.result.list.map(function (currentValue, index, arr) {
        state.courseList.list.push(currentValue)
      })
    }
  }
}

export default {
  state,
  actions,
  mutations
}
