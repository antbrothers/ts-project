export const GOODCOURSE = 'GOODCOURSE'
