export const COURSELIST = 'COURSELIST'
