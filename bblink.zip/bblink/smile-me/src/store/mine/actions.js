import * as types from './mutationType'
import {fetch} from '../../common/fetch'
/**
 * 我的随堂测试分页列表
 * @param {*} param0
 * @param {*} options
 */
export const myCourseTestList = ({commit}, options) => {
  return fetch({
    url: '/babyapi/api/school/v1.3/myScheduleTestList',
    method: 'get',
    params: {
      pageNo: options.page,
      pageSize: options.size
    },
    success: function (res) {
      if (res.data.code === '0000') {
        commit(types.COURSELIST, {result: res.data.data, page: options.page})
        options._this.$refs.loadmore.onBottomLoaded()
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}
