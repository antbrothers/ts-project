import * as types from './mutationType'
import {fetch} from '../../../src/common/fetch'
/**
 * 获取医院主页列表
 * @param {*} param0
 * @param {*} options
 */
export const hosHomeList = ({commit}, data) => {
  return fetch({
    url: '/api/cms/recommend/hosHomePage',
    method: 'get',
    params: {
      hosId: data.hosId || '',
      schoolId: data.schoolId || ''
    },
    success: function (res) {
      if (res.data.code === '0000') {
        commit(types.HOSHOMELIST, res.data.data)
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}

// 云课堂-->banner数据
export const getHosCourse = ({commit}, data) => {
  return fetch({
    url: '/api/school/live/course/hoscourse',
    method: 'get',
    params: {
      hosId: data.hosId
    },
    success: function (res) {
      if (res.data.code === '0000') {
        commit(types.HOSCOURSE, res.data.data)
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}

// 云课堂-->精选好课
export const getJxhkList = ({commit}, data) => {
  return fetch({
    url: '/api/school/live/course/expert/list',
    method: 'get',
    params: {
      hosId: data.hosId,
      pageNo: data.pageNo,
      pageSize: data.pageSize
    },
    success: function (res) {
      if (res.data.code === '0000') {
        commit(types.JXHKLIST, res.data.data.list)
        commit(types.JXHKPAGE, res.data.data.totalCount)
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}

// 云课堂-->主题系列课
export const getThemeList = ({commit}, data) => {
  return fetch({
    url: '/api/school/live/course/mom/list',
    method: 'get',
    params: {
      hosId: data.hosId,
      pageNo: data.pageNo,
      pageSize: data.pageSize
    },
    success: function (res) {
      if (res.data.code === '0000') {
        commit(types.THEMELIST, res.data.data.list)
      }
      if (res.data.code === '0000' && res.data.data.totalCount <= data.pageNo * data.pageSize) {
        data.vue.allLoaded = true
      }
    },
    fail: function (err) {
      console.log(err)
    }
  })
}
