import * as types from './mutationType'
import * as actions from './actions'
const state = () => ({
  hosHomeList: {},
  cloudClassList: {
    jxhkList: [],
    jxhkPage: 0,
    bannerDate: {},
    themeList: []
  }
})
const mutations = {
  [types.HOSHOMELIST] (state, result) {
    state.hosHomeList = result
  },
  [types.JXHKLIST] (state, result) {
    state.cloudClassList.jxhkList = result
  },
  [types.JXHKPAGE] (state, result) {
    state.cloudClassList.jxhkPage = result
  },
  [types.HOSCOURSE] (state, result) {
    state.cloudClassList.bannerDate = result
  },
  [types.THEMELIST] (state, result) {
    for (var i = 0; i < result.length; i++) {
      state.cloudClassList.themeList.push(result[i])
    }
  },
  [types.DELTHEMELIST] (state, result) {
    state.cloudClassList.themeList = []
  }
}
export default {
  actions,
  state,
  mutations
}
