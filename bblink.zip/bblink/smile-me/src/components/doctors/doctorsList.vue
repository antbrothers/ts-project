<template>
  <div>
    <img :src="aaa" alt="" style="display: none;">
    <div class="doctor-main">
      <mt-loadmore v-if='isShow' :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" ref="loadmore" :auto-fill='false'>
        <div v-for="(item, index) of serviceDoctors" :key="index" class="list-contain" @click="doctorPage({doctorCode: item.accountNo, doctorId: item.providerId, source: 5})">
          <div class="left-module">
            <img :src="item.photo ? item.photo : 'https://image.bblink.cn/moren.png'" class="tx" alt="">
          </div>
          <div class="right-module">
            <div class="right-top">
              <span class="name">{{item.doctorName}}</span>
              <span class="zw">{{item.titleName}}</span>
            </div>
            <div class="right-middle">
              {{item.hosName}}
            </div>
            <div class="right-desc">
              擅长：{{item.feature}}
            </div>
            <div class="btn" :src="aaa">
              找TA服务
            </div>
          </div>
        </div>
      </mt-loadmore>
    </div>
    <div v-show='isShow && all' class='nomore' style='text-align:center'>
        没有更多了
    </div>
    <div class='opca'>
    </div>
    <div class='isnone' v-if='!isShow' style='text-align:center'>
      <img src="../../assets/img/none.png" alt="">
      <span>暂无数据</span>
    </div>
  </div>
</template>
<style lang="less" scoped src='../../../src/assets/less/doctorList.less'></style>
<script>
import { mapState } from 'vuex'
import { domain } from '../../common/domain'
export default {
  computed: {
    ...mapState({
      serviceDoctors: state => state.doctors.doctorList,
      totalCount: state => state.doctors.totalCount,
      isShow: state => state.doctors.isShow,
      dlength: state => state.doctors.dlength
    })
  },
  data () {
    return {
      page: 1,
      allLoaded: false,
      all: false,
      aaa: ''
    }
  },
  mounted () {
    this.$store.dispatch('clear')
    this.$store.dispatch('getServiceDoctorList', {hosId: this.$route.query.hosId, page: this.page})
    let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
    // 服务医生列表打点 3-hos-serv-doctor
    this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-serv-doctor&open_id=' + openId + '&service_id=&doctor_id='
  },
  methods: {
    loadBottom () {
      this.page++
      var op = {hosId: this.$route.query.hosId, page: this.page}
      if (this.dlength < this.totalCount) {
        setTimeout(() => {
          this.$store.dispatch('getServiceDoctorList', op)
          this.$refs.loadmore.onBottomLoaded()
        }, 1000)
      } else {
        this.allLoaded = true
        setTimeout(() => {
          this.all = true
          this.$refs.loadmore.onBottomLoaded()
        }, 1000)
      }
    },
    doctorPage (options) {
      let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
      // 点击头像和【找TA服务】 3-hos-serv-doctorinfo-click
      this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-serv-doctorinfo-click&open_id=' + openId + '&service_id=&doctor_id='
      window.location.href = domain.url + '/#/doctorHomepage?doctorCode=' + options.doctorCode + '&doctorId=' + options.doctorId + '&source=' + options.source
    }
  },
  watch: {
    hosId () {
      this.$store.dispatch('getServiceDoctorList', {hosId: this.$route.query.hosId, page: this.page})
    }
  }
}
</script>
<style  scoped lang='less'>
.isnone {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  img {
    margin-top: 200px;
    width:240px;
    height:240px;
  }
  span {
    margin-top:32px;
    font-size:30px;
    font-family:PingFangSC-Regular;
    color:rgba(136,136,136,1);
    line-height:26px;
  }
}
.opca{
  opacity: 0;
  height:98px;
}
.nomore {
  //background:rgb(242, 242, 242);
  text-align: center;
  height: 80px;
  line-height: 80px;
  color: #999;
  font-size: 23px; /* px */
}
.tx {
  border-radius: 50%;
}
// .btn {
//   position: absolute;
//   bottom: 50px;
// }
</style>
