<template>
  <div>
    <img :src="aaa" alt="" style="display: none;">
    <div class="doctor-main">
      <mt-loadmore v-if='isShow' :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" ref="loadmore" :auto-fill='false'>
        <div v-for="(item, index) of doctors" :key="index" class="list-contain">
          <div class="left-module">
            <img :src="item.photo ? item.photo : 'https://image.bblink.cn/moren.png'" class="tx" alt="" @click="doctorPage({doctorCode: item.doctorCode, doctorId: item.doctorId, source: 3})">
          </div>
          <div class="right-module">
            <div class="right-top">
              <span class="name">{{item.doctorName}}</span>
              <span class="zw">{{item.name}}</span>
              <span class="price">¥{{Number(item.price/100).toFixed(2)}}</span>
            </div>
            <div class="right-middle">
              {{item.hosName}}
            </div>
            <div class="right-desc">
              擅长：{{item.feature}}
            </div>
            <div class="btn" @click="preWenZhenPage(item.doctorCode)">
              向TA问诊
            </div>
          </div>
        </div>
      </mt-loadmore>
    </div>
      <div v-show='isShow && all' class='nomore' style='text-align:center'>
        没有更多了
      </div>
      <div class='opca'>
      </div>
      <div class='isnone' v-if='!isShow' style='text-align:center'>
        <img src="../../assets/img/none.png" alt="">
        <span>暂无数据</span>
      </div>
  </div>
</template>
<style lang="less" scoped src='../../../src/assets/less/doctorList.less'></style>
<script>
import { mapState } from 'vuex'
import { domain } from '../../common/domain'
import { MessageBox } from 'mint-ui'
import { fetch } from '../../common/fetch'
export default {
  computed: {
    ...mapState({
      doctors: state => state.doctors.menZhenDoctorsList,
      totalCount: state => state.doctors.mzTotalCount,
      mzlength: state => state.doctors.mzlength,
      isShow: state => state.doctors.menZhenShow
    })
  },
  data () {
    return {
      page: 1,
      allLoaded: false,
      all: false,
      aaa: '',
      categoryCode: this.$route.query.categoryCode,
      code: this.$route.query.code
    }
  },
  mounted () {
    this.$store.dispatch('mzclear')
    this.$store.dispatch('getMenZhenDoctorList', {code: this.code, page: this.page, version: 'v1.2'})
    let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
    // 门诊医生列表 3-hos-clinic-doctor
    this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-clinic-doctor&open_id=' + openId + '&service_id=&doctor_id='
  },
  methods: {
    loadBottom () {
      this.page++
      var op = {code: this.code, page: this.page, version: 'v1.2'}
      if (this.mzlength < this.totalCount) {
        setTimeout(() => {
          this.$store.dispatch('getMenZhenDoctorList', op)
          this.$refs.loadmore.onBottomLoaded()
          console.log(this.mzlength)
          console.log(this.totalCount)
        }, 1000)
      } else {
        console.log(this.mzlength, this.totalCount)
        // 没有更多
        this.allLoaded = true
        setTimeout(() => {
          this.all = true
          this.$refs.loadmore.onBottomLoaded()
        }, 1000)
      }
    },
    preWenZhenPage (doctorCode) {
      let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
      this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-clinic-doctor-click&open_id=' + openId + '&service_id=&doctor_id='
      fetch({
        url: '/api/inquiry/order/temp/v2',
        method: 'post',
        data: {
          'doctorCode': doctorCode,
          'source': '1',
          'sourceId': this.code,
          'parentSourceId': this.categoryCode
        },
        success: (res) => {
          let body = res.data
          console.log(body)
          if (body.data.status === 1) {
            return window.location.replace(`${domain.url}/?#/find-doctor/pay?code=${body.data.code}&inquiryType=fuer`)
          }
          if (body.code === '4001') {
            return MessageBox.confirm('您与该医生正在会话中，是否立即进入会话', '继续问诊', {
              closeOnClickModal: false
            }).then(action => {
            // 点击确定进入等待问诊状态
              window.location.href = domain.url + '/#/find-doctor/wait-diagnose?code=' + body.data.code
            }).catch((action) => {
            // 取消
            })
          }
          window.location.href = domain.url + '/#/find-doctor/ask_doctors?tempId=' + body.data.tempID + '&type=1&inquiryType=fuer'
        },
        fail: (err) => {
          console.log(err)
        }
      })
    },
    doctorPage (options) {
      let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
      // 点击医生头像问诊 3-hos-clinic-doctorinfo-click
      this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-clinic-doctorinfo-click&open_id=' + openId + '&service_id=&doctor_id='
      window.location.href = domain.url + '/#/doctorHomepage?doctorCode=' + options.doctorCode + '&doctorId=' + options.doctorId + '&source=' + options.source
    }
  },
  watch: {
    hosId () {
      this.$store.dispatch('getMenZhenDoctorList', {code: this.code, page: this.page, version: 'v1.2'})
    }
  }
}
</script>
<style scoped lang='less'>
.isnone {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  img {
    margin-top: 200px;
    width:240px;
    height:240px;
  }
  span {
    margin-top:32px;
    font-size:30px;
    font-family:PingFangSC-Regular;
    color:rgba(136,136,136,1);
    line-height:26px;
  }
}
.opca{
  opacity: 0;
  height:98px;
}
.nomore {
  //background:rgb(242, 242, 242);
  text-align: center;
  height: 80px;
  line-height: 80px;
  color: #999;
  font-size: 23px; /* px */
}
.tx {
  border-radius: 50%;
}
// .right-desc {
// }
// .btn {
//   position: absolute;
//   bottom: 30px;
// }
// .list-contain {
//   height: 180px;
// }
</style>
