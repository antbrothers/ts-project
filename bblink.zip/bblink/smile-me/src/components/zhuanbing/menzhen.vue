<template>
  <div class="menzhen">
    <div class="menzhen-main">
      <div class="more-main">
        <div class="page health-tips">
          <section class="no-footer">
            <mt-loadmore :bottom-status.sync="bottomStatus" :bottom-method="loadBottom" :bottom-distance="distance" :auto-fill="autoFill" :bottomAllLoaded='allowPull' ref="loadmore">
              <div>
                <Hospital :hosd="hosDetail"></Hospital>
              </div>
              <div class="empty-20"></div>
               <div v-for="(item, index) in outPatient.dt.list" v-bind:key="index">
                  <div class="list-main">
                    <div class="list-head">
                      <div class="menzhen-desc">{{item.name}}</div>
                      <div class="menzhen-label">
                        <div class="lable-comm" v-for="(childItem, childIndex) in labelArr(item.keyword)" :key="childIndex">
                          {{childItem}}
                        </div>
                      </div>
                    </div>
                    <div class="right" @click="jump(item.categoryCode, item.code)">
                      <img src="../../assets/img/right-icon.png" class="right-icon" alt="" />
                    </div>
                  </div>
                  <div class="list-main-swiper">
                    <Yunchan :doctorList='item.outPatientDoctors' :parent='item'></Yunchan>
                  </div>
                </div>
            </mt-loadmore>
          </section>
          <div class="no-data" v-if="allowPull">{{doneMore}}</div>
          <img :src="aaa" alt="" style="display:none;">
        </div>
      </div>
    </div>
  </div>
</template>
<style lang="less" scoped src='../../../src/assets/less/menzhen.less'></style>
<script>
import Yunchan from './yunchan'
import Hospital from '../hostpital-header/index'
import { mapState } from 'vuex'
export default {
  computed: {
    ...mapState({
      hosDetail: state => state.hosDetail.dt,
      outPatient: state => state.outPatient
    })
  },
  components: {
    Yunchan,
    Hospital
  },
  data () {
    return {
      page: 1,
      size: 10,
      distance: 80,
      autoFill: false,
      bottomStatus: '',
      allowPull: false,
      doneMore: '没有更多数据',
      aaa: '',
      id: ''
    }
  },
  mounted () {
    this.getHosDetailData(this.$route.query.hosId)
    this.getOutpatientData()
    let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
    this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-specialist-clinic&open_id=' + openId + '&service_id=&doctor_id='
  },
  methods: {
    getHosDetailData (hosId) {
      this.$store.dispatch('getHosDetail', { hosId: hosId, vue: this })
    },
    async getOutpatientData () {
      await this.$store.dispatch('getOutpatient', {hosId: this.$route.query.hosId, page: this.page, size: this.size})
      if (this.outPatient.dt.totalCount <= this.outPatient.dt.list.length) {
        this.allowPull = true
      }
    },
    labelArr (lableStr) {
      return lableStr.split(',')
    },
    jump (categoryCode, code) {
      // console.log(categoryCode, code)
      this.$router.push({path: '/menzhendoctor', query: {'categoryCode': categoryCode, 'code': code}})
    },
    loadBottom () {
      var _this = this
      _this.page = _this.page + 1
      setTimeout(function () {
        _this.getOutpatientData()
        _this.$refs.loadmore.onBottomLoaded()
      }, 1000)
    }
  }
}
</script>
