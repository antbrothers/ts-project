<template>
  <div class="yunchan-main">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide" v-for="(item, index) in doctorList" :key="index">
          <div class="list">
            <img :src="calulateTx(item.photo)" class="tx" alt=""  @click='goHomepage(item.doctorCode)'>
            <div class="user-com">
              <span class="name">{{item.doctorName}}</span>
              <span class="zc">{{item.name}}</span>
            </div>
            <div class="price">
              ¥{{(item.price/100).toFixed(2)}}
            </div>
            <div class="btn" @click="askQuestion(item.doctorCode, parent.categoryCode, parent.code)">
              找TA问诊
            </div>
          </div>
        </div>
      </div>
    </div>
    <img :src="aaa" alt="" style="display:none;">
  </div>
</template>
<style lang="less" scoped src='../../../src/assets/less/yunchan.less'></style>
<script>
import { fetch } from '../../common/fetch'
import { domain } from '../../common/domain'
import { MessageBox } from 'mint-ui'
export default {
  data () {
    return {
      aaa: ''
    }
  },
  props: ['doctorList', 'parent'],
  mounted () {
    this.bannerSwiper()
  },
  methods: {
    bannerSwiper () {
      /* eslint-disable */
      var bannerSwiper = new Swiper('.swiper-container', {
        slidesPerView: 2.3,
        spaceBetween: 10,
        freeMode: true
      })
    },
    calulateTx (tx) {
      return tx === '' ? 'https://image.bblink.cn/moren.png' : tx
    },
    // 跳到医生主页
    goHomepage (doctorCode) {
      let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
      this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-clinic-doctorinfo-click&open_id=' + openId + '&service_id=&doctor_id='
      window.location.href = domain.url + '/#/doctorHomepage?doctorCode=' + doctorCode
    },
    askQuestion (doctorCode, categoryCode, code) {
      let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
      this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-clinic-doctor-click&open_id=' + openId + '&service_id=&doctor_id='
      fetch({
        url: '/api/inquiry/order/temp/v2',
        method: 'post',
        data: {
          'doctorCode': doctorCode,
          'source': '1',
          'sourceId': code,
          'parentSourceId': categoryCode
        },
        success: (res) => {
          let body = res.data
          console.log(body)
          if (body.data.status === 1) {
              return window.location.replace(`${domain.url}/?#/find-doctor/pay?code=${body.data.code}&inquiryType=fuer`)
          }
          if (body.code === '4001') {
            return MessageBox.confirm('您与该医生正在会话中，是否立即进入会话', '继续问诊', {
                      closeOnClickModal: false
                  }).then( action => {
                    //点击确定进入等待问诊状态
                    window.location.href = domain.url + '/#/find-doctor/wait-diagnose?code=' + body.data.code
                  }).catch((action) => {
                    //取消
                  })
          }
          //     return MessageBox.confirm('您与该医生正在会话中，是否立即进入会话', '继续问诊', {
          //         closeOnClickModal: false
          //     }).then((action) => {
          //         //点击确定进入等待问诊状态
          //         this.$router.push({
          //             path: "/find-doctor/wait-diagnose",
          //             query: {
          //                 code: body.data.code
          //             }
          //         })
          //     }).catch((action) => {
          //         //取消
          //     })
          // }
          window.location.href = domain.url + '/#/find-doctor/ask_doctors?tempId=' + body.data.tempID + '&type=1&inquiryType=fuer'
          // store.commit('sickImageList', [])
          // store.commit('sickContent', '')
          // this.$router.push({
          //   path: '/find-doctor/ask_doctors',
          //   query: {
          //     tempId: body.data.tempID,
          //     type: this.doctorDetails.type,
          //     inquiryType: 'fuer'
          //   }
          // })
        },
        fail: (err) => {
          console.log(err)
        }
      })
    }
  }
}
</script>
