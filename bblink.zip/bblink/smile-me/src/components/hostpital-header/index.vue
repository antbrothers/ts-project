<template>
  <div style="background:#fff;">
    <div class="myArchivesHospital">
      <div class="hospitalInfo_right">
        <img src="../../assets/img/hos-img.png" alt="">
      </div>
      <div class="hospitalInfo_left">
        <h4>{{hosDetail.hosName}}</h4>
        <p>
          <span class="hos-level" v-if="hosDetail.level">{{hosDetail.level}}</span>
          <span>年分娩量:    {{hosDetail.birthNum}}</span>
        </p>
      </div>
    </div>
    <div class="hospita-address" @click='goNavigation(hosDetail.hosName, hosDetail.cityName, hosDetail.countyName, hosDetail.addr)'>
      <div class="address-info">
        <img class="map-icon" src="../../assets/img/icon_dizhi@2x.png" alt="">
        <span class="address-name">{{hosDetail.cityName+hosDetail.countyName+hosDetail.addr}}</span>
      </div>
      <img class="right-icon" src="../../assets/img/right-icon.png" alt="">
    </div>
    <div class="hospita-tel" @click='showphone'>
      <div style='display: flex;align-items: center;'>
        <img class="tel-icon" src="../../assets/img/icon_dianhua@2x.png" alt="">
        <span class="tel-text">联系方式</span>
        <span class="tel-more">{{hosDetail.tel}}</span>
      </div>
      <img class="right-icon" src="../../assets/img/right-icon.png" alt="">
    </div>
    <!-- <mt-popup
      v-model="popupVisible"
      popup-transition="popup-fade"
      position="bottom"
      class='phoneModels'>
      <div class='bigbox'>
        <div>
          <a :href="'tel:'+ hosDetail.tel" class='telll'>
            <img class="tel-img" src="../../assets/img/tel.png" alt="">{{hosDetail.tel}}</a>
        </div>
        <div></div>
        <div @click='closephone'>取消</div>
      </div>
    </mt-popup> -->
    <mt-popup v-model="popupVisible" position="bottom" class='phoneModels'>
      <div v-for="(item, index) in telArr" :key="index">
        <a :href="'tel://' + item" class='telll'>
          <img class="tel-img" src="../../assets/img/tel.png" alt="">
          <span>{{item}}</span>
        </a>
      </div>
      <div @click='closephone'>取消</div>
    </mt-popup>
  </div>
</template>
<script>
import { domain } from '../../common/domain'
export default {
  computed: {
    hosDetail: function () {
      return this.hosd
    },
    telArr: function () {
      if (this.hosd.tel !== undefined) {
        return this.hosd.tel.split(',')
      }
    }
  },
  props: ['hosd'],
  data () {
    return {
      popupVisible: false,
      id: ''
    }
  },
  methods: {
    showphone () {
      this.popupVisible = true
    },
    closephone () {
      this.popupVisible = false
    },
    // 跳转至导航页
    goNavigation (hosName, cityName, countyName, address) {
      let addr = cityName + countyName + address
      location.href = domain.url + '/#/hospital/details/navigation?hosName=' + hosName + '&address=' + addr
    }
  }
}
</script>
<style scoped lang="less">
.myArchivesHospital {
  width: 100%;
  height: 188px;
  padding: 32px 0 36px 40px;
  box-sizing: border-box;
  display: flex;
  .hospitalInfo_right {
    width: 120px;
    height: 120px;
    margin-right: 34px;
    border-radius: 14px;
    overflow: hidden;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .hospitalInfo_left {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    h4 {
      font-size: 32px;
      font-family: PingFangSC-Regular;
      color: rgba(51, 51, 51, 1);
      line-height: 44px;
    }
    p {
      display: flex;
      span {
        font-family: PingFang-SC-Regular;
        font-size: 24px; /* px */
        color: #999;
      }
      .hos-level {
        text-align: center;
        // display: inline-block;
        width: 132px;
        // height: 20px;
        // line-height: 20px;
        // padding-top:10px;
        // padding-bottom: 10px;
        display: flex;
        justify-content: center;
        align-items: center;
        // border-radius: 25px;
        color: rgba(255, 112, 112, 1);
        // border: 1px solid rgba(255, 112, 112, 1); /* px */
        position: relative;
        margin-right: 30px;
        &:before {
          content: '';
          width: 200%;
          height: 200%;
          border-radius: 50px;
          position: absolute;
          top: 0;
          left: 0;
          border: 1px solid rgba(255, 112, 112, 1); /* no */
          transform: scale(0.5);
          transform-origin: 0 0;
          box-sizing: border-box;
          pointer-events: none;
        }
      }
    }
  }
}
.hospita-address {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-left: 24px;
  padding: 24px 22px 28px 0;
  // border-top: 1px solid #ddd;
  height: 91px;
  position: relative;
  box-sizing: border-box;
  &:before {
    content: '';
    width: 200%;
    height: 200%;
    position: absolute;
    top: 0;
    left: 0;
    border-top: 1px solid #ddd; /* no */
    transform: scale(0.5);
    transform-origin: 0 0;
    box-sizing: border-box;
    pointer-events: none;
  }
  .address-info {
    display: flex;
    align-items: center;
  }
  .map-icon {
    width: 26px;
    height: 32px;
    margin-right: 30px;
  }
  .address-name {
    font-size: 28px;
    width: 620px;
    overflow: hidden;
    text-overflow:ellipsis;
    white-space:nowrap
  }
}
.hospita-tel {
  height: 91px;
  box-sizing: border-box;
  // border-top: 1px solid #ddd;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-left: 24px;
  padding: 24px 22px 28px 0;
  color: #999999;
  font-size: 28px;
  position: relative;
  &:before {
    content: '';
    width: 200%;
    height: 200%;
    position: absolute;
    top: 0;
    left: 0;
    border-top: 1px solid #ddd; /* no */
    transform: scale(0.5);
    transform-origin: 0 0;
    box-sizing: border-box;
    pointer-events: none;
  }
  .tel-icon {
    width: 26px;
    height: 32px;
  }
  .tel-text {
    margin: 0 24px 0 30px;
    color: #333333;
  }
  .tel-more {
    display: block;
    width: 480px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
}
.right-icon {
  width: 14px;
  height: 24px;
}
  .phoneModels {
    width:100%;
    background: #fff;
    font-size: 30px;
    div {
      height: 90px;
      box-sizing: border-box;
      line-height: 90px;
      text-align: center;
      border-top:1px solid #ddd;
      color:#333;
      .telll {
        color:#333;
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration:none;
        .tel-img {
          width: 28px;
          height: 28px;
          margin-right: 12px;
        }
      }
    }
  }
</style>
