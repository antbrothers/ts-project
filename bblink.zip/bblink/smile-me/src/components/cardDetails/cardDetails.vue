<template>
<div class="page">
  <div class="bac card-title">
    <div class="title">
      <img src="../../assets/img/Group6.png"/>
      <span class="title-font">孕妇服务卡</span>
    </div>
    <div class="time">
      <div class="time-left"><span>有效期至</span><span>2018年08年08日</span></div>
      <div class="time-right"><span>1999</span><span>元</span></div>
    </div>
  </div>
  <div class="bac card-project">
    <div class="title-line">
      <span class="title-text">服务项目</span>
    </div>
    <div class="project">
      <div class="project-class"><span class="black"></span><span class="black-text">5次免费问诊</span></div>
      <div class="project-class"><span class="black"></span><span class="black-text">3次免费课程</span></div>
      <div class="project-class"><span class="black"></span><span class="black-text">免费母婴热线</span></div>
    </div>
  </div>
  <div class="bac card-doctor">
    <div class="title-line">
      <span class="title-text">服务医生</span>
    </div>
    <div class="doctor-list">
      <div class="doctor">
        <div class="doctor-left">
        <div class="doctor-img"><img src="../../assets/img/Group4.png" /></div>
        <div class="doctor-title">
          <div class="marginb-24">
            <span class="font-32 margin-18">王志强</span>
            <span class="font-24">主治医师</span>
          </div>
          <div>
            <span class="font-28 margin-20">妇产科</span>
            <span class="font-28">上海第一妇幼保健院保健院</span>
          </div>
        </div>
        </div>
        <div class="doctor-right">
          <img src="../../assets/img/icon_queren.png"/>
        </div>
      </div>
      <div class="doctor">
        <div class="doctor-left">
        <div class="doctor-img"><img src="../../assets/img/Group4.png" /></div>
        <div class="doctor-title">
          <div class="marginb-24">
            <span class="font-32 margin-18">王志强</span>
            <span class="font-24">主治医师</span>
          </div>
          <div>
            <span class="font-28 margin-20">妇产科</span>
            <span class="font-28">上海第一妇幼保健院保健院</span>
          </div>
        </div>
        </div>
        <div class="doctor-right">
          <img src="../../assets/img/icon_queren2.png"/>
        </div>
      </div>
      <div class="doctor">
        <div class="doctor-left">
        <div class="doctor-img"><img src="../../assets/img/Group4.png" /></div>
        <div class="doctor-title">
          <div class="marginb-24">
            <span class="font-32 margin-18">王志强</span>
            <span class="font-24">主治医师</span>
          </div>
          <div>
            <span class="font-28 margin-20">妇产科</span>
            <span class="font-28">上海第一妇幼保健院保健院</span>
          </div>
        </div>
        </div>
        <div class="doctor-right">
          <img src="../../assets/img/icon_queren2.png"/>
        </div>
      </div>
      <div class="zhan">
        展开
      </div>
    </div>
  </div>
  <div class="bac card-details">
    <div class="title-line">
      <span class="title-text">服务详情</span>
    </div>
  </div>
  <div class="bottom">
    <div class="card-service">
      <img src="../../assets/img/ke.png"/><br/>
      <span>联系客服</span>
    </div>
    <div class="card-price">
      <span>实付：￥</span><span>998</span>
    </div>
    <div class="card-btn">
      立即购买
    </div>
  </div>
</div>
</template>
<script>
export default {
}
</script>

<style scoped>
.page{
  background: #F4F4F4;
}
.bac{
  background:#FFFFFF;
  padding-left: 24px;
  padding-right: 24px;
}
.card-title{
  height: 200px;
}
.title{
  height: 120px;
  line-height: 120px;
  border-bottom: solid #DDDDDD 1px;
}
.title img{
  display: inline-block;
  vertical-align: middle;
  margin-right: 15px;
}
.title-font{
  font-size: 30px; /* px */
  color: #333333;
}
.time{
  height: 76px;
  line-height: 76px;
}
.time div{
  display: inline;
}
.time-left{
  float: left;
}
.time-left span{
  font-size: 28px;
  color: #999999;
}
.time-right{
 float: right;
}
.time-right span{
  font-size: 28px;
  color: #FF7070;
}
.card-project{
  margin-top: 20px;
}
.title-line{
  height: 88px;
  line-height: 88px;
  border-bottom: solid #DDDDDD 1px;
}
.title-text{
  width: 148px;
  height: 32px;
  border-left: solid #FF7070 4px;
  font-size: 32px;
  padding-left: 16px;
}
.project-class{
  display:flex;
  height: 88px;
  line-height: 88px;
  align-items:center;
}
.black{
  width: 12px;
  height: 12px;
  display:inline-block;
  background: #FF7070;
  border-radius: 10px;
  line-height: 88px;
  margin-left: 12px;
}
.black-text{
  font-size: 30px;
  padding-left: 12px;
}
.card-doctor{
  margin-top: 20px;
}
.doctor{
  height: 160px;
  display:flex;
  /* justify-content:center; */
  align-items:center;
  border-bottom: solid #DDDDDD 1px;
}
.doctor-img{
  display:inline-block;
  float: left;
  vertical-align: middle;
}
.doctor-img img{
  width: 100px;
  height: 100px;
  vertical-align: middle;
}
.doctor-title{
  display:inline-block;
  float: left;
  margin-left: 24px;
}
.font-32{
  font-size: 32px;
}
.font-24{
  font-size: 24px;
}
.font-28{
  font-size: 28px;
}
.margin-18{
  margin-right: 18px;
}
.margin-20{
  margin-right: 20px;
}
.marginb-24{
  margin-bottom: 24px;
}
.doctor-right{
  height: 160px;
  line-height: 160px;
  margin-left: 70px;
}
.doctor-right img{
  width: 40px;
  height: 40px;
}
.card-details{
  margin-top: 20px;
  margin-bottom: 120px;
}
.zhan{
  height: 88px;
  line-height: 88px;
  font-size: 28px;
  color: #619BFF;
  text-align: center;
}
.bottom {
  height: 98px;
  position: fixed;
  bottom: 0px;
}
.bottom div{
  display:inline-block;
  /* justify-content:center; */
  align-items:center;
  float: left;
  height: 98px;
  text-align: center;
}
.card-service{
  width: 170px;
  background: #FAFAFA;
  color: #7F8389;
}
.card-service img{
  margin-top: 18px;
}
.card-price{
  width: 290px;
  line-height: 98px;
  background: #FFFFFF;
  color: #FF7070;
  font-size: 32px;
}
.card-btn{
  width: 290px;
  line-height: 98px;
  background: #FF7070;
  color: #FFFFFF;
  font-size: 32px;
}

</style>
