<template>
  <div>
    <div class='content_list'>
      <mt-loadmore v-if='isshows>0' :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" ref="loadmore" :auto-fill='false'>
        <div>
          <div class='card' v-for='(item, index) in det' :key='index' @click='goclassrecord(item.scheduleId, item.courseId)'>
            <div class='card_left'>
              <div class='mouth'>{{mounth(item.startTime)}}月</div>
              <div class='day'>{{day(item.startTime)}}</div>
              <div class='week'>{{week(item.startTime)}}</div>
            </div>
            <div class='card_right'>
              <p class='title'>{{item.courseName}}</p>
              <p>开课时间: {{formateTime(item.startTime,item.endTime)}}</p>
              <!-- <p>讲师: <span v-for='(te, i) in item.lecturerList' :key='i'>{{te.lecturerName}}</span></p> -->
              <p>讲师: <span v-for='(te, i) in item.lecturerList' :key='i' class='dian'>{{te.lecturerName}} <time>、</time></span></p>
            </div>
          </div>
        </div>
      </mt-loadmore>
    </div>
    <div v-show='isshows && all' class='nomore'>
      没有更多了
    </div>
    <div class='isnone' v-if='!isshows'>
      <img src="../../assets/img/none.png" alt="">
      <span>暂无数据</span>
    </div>
    <div class='opca'>
    </div>
    <img :src="aaa" alt="" style="display:none;">
  </div>
</template>

<script>
import { tool } from '../../common/util'
import { fetch } from '../../common/fetch'
// import { mapState } from 'vuex'
export default {
  // computed: {
  //   ...mapState({
  //     det: state => state.scheduleList.schedule,
  //     totalCount: state => state.scheduleList.totalcount
  //   })
  // },
  data () {
    return {
      allLoaded: false,
      all: false,
      i: 1,
      det: [],
      totalCount: 0,
      isshows: true,
      aaa: ''
    }
  },
  props: ['schoolId'],
  methods: {
    // 返回时间
    too (time) {
      if (time > 0) {
        return tool.dateFormat(new Date(time))
      } else {
        return ''
      }
    },
    // 月
    mounth (time) {
      if (time > 0) {
        var date = new Date(time)
        var M = date.getMonth() + 1
        return M
      } else {
        return ''
      }
    },
    // 日
    day (time) {
      if (time > 0) {
        var date = new Date(time)
        var D = date.getDate()
        return D
      } else {
        return ''
      }
    },
    // 周
    week (time) {
      var date = new Date(time).getDay()
      var week
      if (time > 0) {
        switch (date) {
          case 0:
            week = '周日'
            break
          case 1:
            week = '周一'
            break
          case 2:
            week = '周二'
            break
          case 3:
            week = '周三'
            break
          case 4:
            week = '周四'
            break
          case 5:
            week = '周五'
            break
          case 6:
            week = '周六'
            break
        }
        return week
      } else {
        return ''
      }
    },
    // 刷新
    loadTop () {
      // 获取到数据
      // this.$refs.loadmore.onTopLoaded()
      // this.all = false
      // this.allLoaded = false
    },
    // 加载
    loadBottom () {
      this.i++
      var op = {
        schoolId: this.schoolId,
        page: this.i
      }
      if (this.det.length < this.totalCount) {
        setTimeout(() => {
          this.$refs.loadmore.onBottomLoaded()
          this.getClassRecord(op)
        }, 1000)
      } else {
        setTimeout(() => {
          this.all = true
          this.allLoaded = true
          this.$refs.loadmore.onBottomLoaded()
        }, 1000)
      }
    },
    // 获取上课记录
    getClassRecord (op) {
      fetch({
        url: '/babyapi/api/school/v1.3/myScheduleList',
        method: 'get',
        params: {
          schoolId: op.schoolId ? op.schoolId : '',
          page: op.page ? op.page : 1,
          size: op.size ? op.size : 10
        },
        success: (res) => {
          res.data.data.list.forEach((v, k) => {
            this.det.push(v)
          })
          if (this.det.length === 0) {
            this.isshows = false
          }
          this.totalCount = res.data.data.totalCount
        },
        fail: function (err) {
          console.log(err)
        }
      })
    },
    //  格式化时间
    formateTime (beginStr, endStr) {
      if (beginStr > 0) {
        var obj = new Date(beginStr)
        var endObj = new Date(endStr)
        return (obj.getHours().toString().length === 2 ? obj.getHours() : '0' + obj.getHours()) + ':' + (obj.getMinutes().toString().length === 2 ? obj.getMinutes() : '0' + obj.getMinutes()) + '-' + (endObj.getHours().toString().length === 2 ? endObj.getHours() : '0' + endObj.getHours()) + ':' + (endObj.getMinutes().toString().length === 2 ? endObj.getMinutes() : '0' + endObj.getMinutes())
      } else {
        return ''
      }
    },
    goclassrecord (scheduleId, courseId) {
      this.$router.push({path: '/curriculumDetails', query: {scheduleId: scheduleId, courseId: courseId}})
    }
  },
  mounted () {
    // localStorage.setItem('bblinkToken', 'tokenv1:ZjQyMWEwYjFhZDA0NDM5MGI5NjA0ZjlmNDAwYTg4YTMxNTMzMDI1MjI0MDc5')
    let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
    // 打点 3-hos-pregnschool-record 上课记录
    this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-pregnschool-record&open_id=' + openId + '&service_id=&doctor_id='
    this.getClassRecord({schoolId: this.schoolId})
  }
}
</script>

<style scoped lang='less'>
.content_list {
  background:rgb(242, 242, 242);
  width:750px;
  .card {
    width:710px;
    height:244px;
    background:rgba(255,255,255,1);
    border-radius:8px;
    margin: 20px auto;
    padding: 30px 74px 80px 32px;
    box-sizing: border-box;
    display: flex;
    .card_left {
      width:132px;
      height:134px;
      background:url('../../assets/img/timebg.png') no-repeat;
      background-size: 134px 136px;
      border-radius:14px;
      margin-right: 32px;
      display: flex;
      flex-direction: column;
      justify-content: space-around;
      align-items: center;
      .mouth {
        padding-top: 6px;
        text-align: center;
        font-size:27px;
        color:rgba(255,255,255,1);
      }
      .day {
        font-size: 54px;
        text-align: center;
        display: block;
        height:48px;
        line-height: 58px;
        color:rgba(255,112,112,1);
      }
      .week {
        text-align: center;
        padding-left:6px;
        font-size: 16px;
        color:rgba(255,112,112,1);
        padding-bottom: 10px;
      }
    }
    .card_right {
      width:442px;
      height:134px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-sizing: border-box;
      .title {
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
        font-size:32px;
        font-family:PingFangSC-Regular;
        color:rgba(53,53,53,1);
        line-height:32px;
        margin-top:2px;
      }
      p {
        &:nth-child(2) {
          font-size:28px;
          font-family:PingFangSC-Regular;
          color:rgba(85,85,85,1);
          line-height:26px;
        }
        &:nth-child(3) {
          font-size:24px;
          font-family:PingFangSC-Regular;
          color:rgba(136,136,136,1);
          line-height:24px;
        }
      }
    }
  }
}
.isnone {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding-top: 328px;
  img {
    width:240px;
    height:240px;
  }
  span {
    margin-top:32px;
    font-size:30px;
    font-family:PingFangSC-Regular;
    color:rgba(136,136,136,1);
    line-height:26px;
  }
}
.opca{
  opacity: 0;
  height:98px;
}
.nomore {
  background:rgb(242, 242, 242);
  text-align: center;
  height: 80px;
  line-height: 80px;
  color: #999;
  font-size: 28px; /* px */
}
.dian {
  &:last-child {
    time {
      display: none;
    }
  }
}
</style>
