<template>
  <div style="background:rgba(242,242,242,1);height:100%;">
    <HostpitalHeader :hosd='hosDetail' v-if='ishead'></HostpitalHeader>
    <List v-if='ishead' :schoolId='hosDetail.schoolId'></List>
    <classList v-else :schoolId='hosDetail.schoolId'></classList>
    <footer class='foot'>
      <div class='foot_choose' @click='choosecheng'>
        <img :src="kecheng" alt="">
        <div :style='{color:chengcolor}'>课程表</div>
      </div>
      <div class='foot_choose' @click='chooseshang'>
        <img :src="shangke" alt="">
        <div :style='{color:shangcolor}'>上课记录</div>
      </div>
    </footer>
    <img :src="aaa" alt="" style="display:none;">
  </div>
</template>

<script>
import HostpitalHeader from '../hostpital-header'
import List from './list'
import { mapState } from 'vuex'
import classList from './classList'
export default {
  components: {
    HostpitalHeader,
    List,
    classList
  },
  computed: {
    ...mapState({
      hosDetail: state => state.hosDetail.dt
    })
  },
  data () {
    return {
      ishead: true,
      allLoaded: false,
      all: false,
      kecheng: require('../../assets/img/kecheng2.png'),
      shangke: require('../../assets/img/shangke1.png'),
      chengcolor: '#FF7070',
      shangcolor: '#999999',
      aaa: '',
      id: ''
    }
  },
  methods: {
    // 课程
    choosecheng () {
      if (this.chengcolor === '#999999') {
        this.chengcolor = '#FF7070'
        this.shangcolor = '#999999'
        this.kecheng = require('../../assets/img/kecheng2.png')
        this.shangke = require('../../assets/img/shangke1.png')
        this.ishead = true
      }
    },
    // 上课记录
    chooseshang () {
      if (this.shangcolor === '#999999') {
        this.shangcolor = '#FF7070'
        this.chengcolor = '#999999'
        this.kecheng = require('../../assets/img/kecheng1.png')
        this.shangke = require('../../assets/img/shangke2.png')
        this.ishead = false
      }
    },
    // 获取医院详情
    getHosDetailData (hosId) {
      this.$store.dispatch('getHosDetail', {hosId: hosId, vue: this})
    }
    // 获取课程表列表
    // getScheduleList () {
    //   this.$store.dispatch('getScheduleList', {schoolId: '5b1a750123744a89b3fbe97f8fa2a2a3'})
    // },
    // 上课记录
    // getClassRecord () {
    //   this.$store.dispatch('getClassRecord', {schoolId: '5b1a750123744a89b3fbe97f8fa2a2a3'})
    // }
  },
  mounted () {
    this.getHosDetailData(this.$route.query.hosId)
    let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
    // 孕校主页 3-hos-pregnschool
    this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-pregnschool&open_id=' + openId + '&service_id=&doctor_id='
  }
}
</script>

<style scoped lang='less'>
.content_list {
  width:750px;
  .card {
    width:710px;
    height:244px;
    background:rgba(255,255,255,1);
    border-radius:8px;
    margin: 20px auto;
    padding: 30px 74px 80px 32px;
    box-sizing: border-box;
    display: flex;
    .card_left {
      width:132px;
      height:134px;
      background:url('../../assets/img/timebg.png') no-repeat;
      background-size: 134px 136px;
      border-radius:14px;
      margin-right: 32px;
      display: flex;
      flex-direction: column;
      justify-content: space-around;
      align-items: center;
      .mouth {
        padding-top: 6px;
        text-align: center;
        font-size:27px;
        color:rgba(255,255,255,1);
      }
      .day {
        font-size: 54px;
        text-align: center;
        display: block;
        height:48px;
        line-height: 58px;
        color:rgba(255,112,112,1);
      }
      .week {
        text-align: center;
        padding-left:6px;
        font-size: 16px;
        color:rgba(255,112,112,1);
        padding-bottom: 10px;
      }
    }
    .card_right {
      width:442px;
      height:134px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-sizing: border-box;
      .title {
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
        font-size:32px;
        font-family:PingFangSC-Regular;
        color:rgba(53,53,53,1);
        line-height:32px;
        margin-top:2px;
      }
      p {
        &:nth-child(2) {
          font-size:28px;
          font-family:PingFangSC-Regular;
          color:rgba(85,85,85,1);
          line-height:26px;
        }
        &:nth-child(3) {
          font-size:24px;
          font-family:PingFangSC-Regular;
          color:rgba(136,136,136,1);
          line-height:24px;
        }
      }
    }
  }
  .isnone {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    img {
      margin-top: 120px;
      width:240px;
      height:240px;
    }
    span {
      margin-top:32px;
      font-size:30px;
      font-family:PingFangSC-Regular;
      color:rgba(136,136,136,1);
      line-height:26px;
    }
  }
}
.foot {
  z-index: 100;
  width:100%;
  position: fixed;
  bottom: 0;
  box-shadow:0px -2px 8px 0px rgba(0,0,0,0.1);
  height:98px;
  background:rgba(250,250,250,1);
  display: flex;
  justify-content: space-around;
  .foot_choose {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    img {
      width: 44px;
      height: 42px;
    }
  }
}
.opca{
  opacity: 0;
  height:98px;
}
.nomore {
  text-align: center;
  height: 80px;
  line-height: 80px;
  color: #999;
  font-size: 12px; /* px */
}
</style>
