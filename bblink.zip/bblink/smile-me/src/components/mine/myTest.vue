<template>
  <div class="sweetown">
    <section class="no-footer">
    <mt-loadmore :bottom-status.sync="bottomStatus" :bottom-method="loadBottom" :bottom-distance="distance" :auto-fill="autoFill" :bottomAllLoaded='allowPull' ref="loadmore">
    <div class="sweetown-list" v-for="(item, index) in courseList.dt.list" :key="index" @click="getCourseDetail(item.queId, item.scheduleId)">
      <div class="list-left">
        <div class="title">{{item.courseName}}</div>
        <div class="date-module">
          {{formateTime(item.startTime,item.endTime)}}
        </div>
        <div class="desc">
          {{item.que}}
        </div>
        <div class="radio-cont">
          <img src="../../assets/img/couter-icon.png" class="couter-icon" alt="" srcset="">
          <span class="timu">共{{item.allTopicCount}}题</span>
        </div>
      </div>
      <div class="list-right">
        <img src="../../assets/img/right-icon.png" class="right-icon" alt="" srcset="">
      </div>
    </div>
    </mt-loadmore>
    </section>
    <div class='isnone' v-if='courseList.dt.list.length === 0'>
      <img src="../../assets/img/none.png" alt="">
      <span>暂无数据</span>
    </div>
     <!-- <div class="no-data">
      上拉刷新
    </div> -->
  </div>
</template>
<style lang="less" scoped src='../../../src/assets/less/sweetown.less'></style>
<script>
import { mapState } from 'vuex'
import { fetch } from '../../common/fetch'
import { domain } from '../../common/domain'
export default {
  computed: {
    ...mapState({
      courseList: state => state.mine
    })
  },
  data () {
    return {
      page: 1,
      size: 10,
      distance: 80,
      autoFill: false,
      bottomStatus: '',
      allowPull: false,
      doneMore: '没有更多数据'
    }
  },
  mounted () {
    this.getCourseListData()
  },
  methods: {
    async getCourseListData () {
      await this.$store.dispatch('myCourseTestList', {page: this.page, size: this.size, _this: this})
      if (this.courseList.dt.totalCount <= this.courseList.dt.list.length) {
        this.allowPull = true
      }
    },
    getCourseDetail (queId, scheduleId) {
      fetch({
        headers: {
          'clazz': 'getQueInfo',
          'packagz': 'school'
        },
        url: '/babyapi/api/v1/school/center',
        mothod: 'get',
        params: {
          queId: queId,
          scheduleId: scheduleId
        },
        success: (res) => {
          if (res.data.code === 0) {
            // let qFinish = res.data.data.hasAnswer === 'N' ? 0 : 1
            if (scheduleId !== '') {
              window.location.href = domain.url + '/fuerhos/school/questions/detail.html?fm=1&qFinish=1&scheduleId=' + scheduleId + '&queId=' + queId
            } else {
              window.location.href = domain.url + '/fuerhos/school/questions/detail.html?fm=1&qFinish=1&queId=' + queId
            }
          }
        },
        fail: (err) => {
          console.log(err)
        }
      })
    },
    loadBottom () {
      var _this = this
      _this.page = _this.page + 1
      _this.getCourseListData()
    },
    formateTime (beginStr, endStr) {
      if (beginStr > 0) {
        var obj = new Date(beginStr)
        var endObj = new Date(endStr)
        return obj.getFullYear() + '-' + ((obj.getMonth() + 1).toString().length === 2 ? (obj.getMonth() + 1) : '0' + (obj.getMonth() + 1)) + '-' + (obj.getDate().toString().length === 2 ? obj.getDate() : '0' + obj.getDate()) + ' ' + (obj.getHours().toString().length === 2 ? obj.getHours() : '0' + obj.getHours()) + ':' + (obj.getMinutes().toString().length === 2 ? obj.getMinutes() : '0' + obj.getMinutes()) + '-' + (endObj.getHours().toString().length === 2 ? endObj.getHours() : '0' + endObj.getHours()) + ':' + (endObj.getMinutes().toString().length === 2 ? endObj.getMinutes() : '0' + endObj.getMinutes())
      //  return tool.dateFormat(str)
      } else {
        return ''
      }
    }
  }
}
</script>
<style scoped lang='less'>
.sweetown{
  height: 100%;
}
.isnone {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  img {
    margin-top: 200px;
    width:240px;
    height:240px;
  }
  span {
    margin-top:32px;
    font-size:30px;
    font-family:PingFangSC-Regular;
    color:rgba(136,136,136,1);
    line-height:26px;
  }
}
</style>
