<template>
  <div class="course-main">
    <div class="doctor-main">
      <section class="no-footer">
        <mt-loadmore :bottom-status.sync="bottomStatus" :bottom-method="loadBottom" :bottom-distance="distance" :auto-fill="autoFill" :bottomAllLoaded='allowPull' ref="loadmore">
          <div class="list-contain" v-for="(item, index) in goodCourseList.courseList.list" :key="index" @click='goodCourseDetail(item.courseId)'>
            <div class="left-module">
              <img :src="calulateTx(item.lecturerPhoto)" class="tx" alt="">
            </div>
            <div class="right-module">
              <div>
                <div class="right-top">
                  <span class="name">{{item.name}}</span>
                </div>
                <div class="right-desc">
                  <span class="gray-text">{{item.lecturerName}}</span>
                  <span>{{item.lecturerTitle}}</span>
                </div>
                <!-- <div class="right-desc" v-html="item.intro"></div> -->
                <div class="hosName">{{item.hosName}}</div>
                <!-- <div class="btn-main" v-if="item.liveStatus === 1 && item.type ==2 && item.item - 7200000 <=0">
                  <div class="btn">
                    <span class="cirle"></span>即将开始
                  </div>
                  <div class="zhibo">距离开课时间</div>
                </div> -->
                <!-- <div v-if="item.type==2&&item.liveStatus==1&&item.time-7200000>0" class="btn-main">
                  <div class="live-time-title">直播时间: </div>
                  <span class="time-title">{{item.lastingTime}}</span>
                </div> -->
                <!-- <div v-if="item.type==2&&item.liveStatus==1&&item.time-7200000<=0" class="btn-main">
                  <div class="btn-info">
                    <div class="spot"></div>
                    <div class="text">即将开始</div>
                  </div>
                  <span class="time-title">距离开课还有：</span>
                  <span class="time">{{formatDuring(item.time)}}</span>
                </div> -->
                <div class="btn-main" v-if="item.type==2&&item.liveStatus==1&&item.time-7200000>0">
                  <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
                  <span class="time-title time-title1">直播时间: </span>
                  <span class="time time1">{{item.lastingTime}}</span>
                </div>
                <div class="btn-main" v-else-if="item.type==2&&item.liveStatus==1&&item.time-7200000<=0">
                  <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
                  <span class="time-title">距离开课还有：</span>
                  <span class="time">{{formatDuring(item.time)}}</span>
                </div>
                <div class="btn-main" v-if="(item.liveStatus === 2 || item.liveStatus === 6 || item.liveStatus === 7) && item.type === 2">
                  <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
                  <div class="zhibo">正在直播</div>
                </div>
                <div class="btn-main" v-if="(item.liveStatus === 3 || item.liveStatus === 5) && item.type === 2">
                  <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
                  <div class="zhibo" style="color: #999">回放</div>
                </div>
                <!-- <div class="btn-main" v-if="item.type === 1 && item.wareType !=='MP4'">
                  <div class="btn kejian">
                    <span class="kejian-icon">
                      <img src="../../assets/img/kj-icon.png" class="kj-icon" alt="">
                    </span>课件
                  </div>
                </div> -->
                <img class="jxhk-btn" v-if="item.type === 1 && item.wareType !=='MP4'" src="../../assets/img/Group 4@2x.png" alt="">
                <img class="jxhk-btn" v-if="item.type === 1 && item.wareType ==='MP4'" src="../../assets/img/Group Copy@2x.png" alt="">
                <!-- <div class="btn-main" v-if="item.type === 1 && item.wareType ==='MP4'">
                  <div class="btn video-btn">
                    <span class="kejian-icon">
                      <img src="../../assets/img/bf-icon.png" class="bf-icon" alt="">
                    </span>视频
                  </div>
                </div> -->
              </div>
            </div>
          </div>
        </mt-loadmore>
      </section>
      <div class="done-more" v-if="allowPull">
        没有更多数据
      </div>
    </div>
    <img :src="aaa" alt="" style="display:none;">
  </div>
</template>
<style lang="less" scoped src='../../../src/assets/less/course.less'></style>
<script>
import { mapState } from 'vuex'
import { domain } from '../../common/domain'
export default {
  computed: {
    ...mapState({
      goodCourseList: state => state.goodCourse
    })
  },
  data () {
    return {
      hosId: '',
      page: 1,
      size: 10,
      distance: 80,
      autoFill: false,
      bottomStatus: '',
      allowPull: false,
      doneMore: '没有更多数据',
      aaa: ''
    }
  },
  mounted () {
    this.hosId = this.$route.query.hosId
    this.getCourseList()
    let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
    this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=4-hos-online-choice&open_id=' + openId + '&service_id=&doctor_id='
  },
  methods: {
    formatDuring (mss) {
      let hours = parseInt((mss % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      let minutes = parseInt((mss % (1000 * 60 * 60)) / (1000 * 60))
      // let seconds = (mss % (1000 * 60)) / 1000
      return hours + '小时' + minutes + '分钟'
    },
    goodCourseDetail (courseId) {
      window.location.href = domain.url + '/#/school/expert-detail?courseId=' + courseId
    },
    async getCourseList () {
      await this.$store.dispatch('getCourseExportList', { hosId: this.hosId, page: this.page, size: this.size, _this: this })
      if (this.goodCourseList.courseList.totalCount <= this.goodCourseList.courseList.list.length) {
        this.allowPull = true
      }
    },
    loadBottom () {
      var _this = this
      _this.page = _this.page + 1
      _this.getCourseList()
    },
    calulateTx (tx) {
      return tx === '' ? 'https://image.bblink.cn/moren.png' : tx
    }
  }
}
</script>
