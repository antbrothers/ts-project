<template>
  <div class="menu">
    <mt-button size="large" type="primary" @click="jump('menzhen')">专病门诊</mt-button>
    <mt-button size="large" type="primary" @click="jump('doctorslist')">服务医生列表</mt-button>
    <mt-button size="large" type="primary" @click="jump('menzhendoctor')">门诊医生列表</mt-button>
    <mt-button size="large" type="primary" @click="jump('sweetown')">随堂测试</mt-button>
    <mt-button size="large" type="primary" @click="jump('hospitalhome')">医生主页</mt-button>
    <mt-button size="large" type="primary" @click="jump('cloudclass')">云课堂</mt-button>
    <mt-button size="large" type="primary" @click="jump('pregnantwomen')">孕妇学校</mt-button>
    <mt-button size="large" type="primary" @click="jump('goodcourse')">精选好课</mt-button>
    <mt-button size="large" type="primary" @click="jump('hospitialDetail')">医院详情</mt-button>
    <mt-button size="large" type="primary" @click="jump('myRecord')">我的上课记录</mt-button>
    <mt-button size="large" type="primary" @click="jump('myTest')">我的测试记录</mt-button>
    <mt-button size="large" type="primary" @click="jump('curriculumDetails')">课程详情</mt-button>
  </div>
</template>
<style scoped>
  .menu {
    padding-left: 20px;
    padding-right: 20px;
    margin-top: 20px;
  }
  .mint-button {
    margin-bottom: 20px;
  }
</style>
<script>
export default {
  methods: {
    jump (url) {
      this.$router.push(url)
    }
  }
}
</script>
