<template>
  <div class="sweetown">
    <section class="no-footer">
      <mt-loadmore :bottom-status.sync="bottomStatus" :bottom-method="loadBottom" :bottom-distance="distance" :auto-fill="autoFill" :bottomAllLoaded='allowPull' ref="loadmore">
        <div>
          <Hospital :hosd="hosDetail"></Hospital>
        </div>
        <div class="empty"></div>
        <div class="sweetown-list" v-for="(item, index) in courseList.dt.list" :key="index" @click='gocourseData(item.signInStatus, item.queId, item.scheduleId)'>
          <div class="list-left">
            <div class="title">{{item.courseName}}</div>
            <div class="date-module">
              {{formateTime(item.startTime, item.endTime)}}
            </div>
            <div class="desc">
              {{item.que}}
            </div>
            <div class="radio-cont">
              <img src="../../assets/img/couter-icon.png" class="couter-icon" alt="" srcset="">
              <span class="timu">共{{item.allTopicCount}}题</span>
            </div>
          </div>
          <div class="list-right">
            <img src="../../assets/img/right-icon.png" class="right-icon" alt="" srcset="">
          </div>
        </div>
      </mt-loadmore>
    </section>
    <div class="no-data" v-if="allowPull">
      没有更多数据
    </div>
  </div>
</template>
<style lang="less" scoped src='../../../src/assets/less/sweetown.less'></style>
<script>
import Hospital from '../hostpital-header/index'
import { mapState } from 'vuex'
// import { tool } from '../../common/util.js'
import { fetch } from '../../common/fetch'
import { domain } from '../../common/domain'
export default {
  computed: {
    ...mapState({
      hosDetail: state => state.hosDetail.dt,
      courseList: state => state.sweetown
    })
  },
  components: {
    Hospital
  },
  data () {
    return {
      schoolId: '',
      page: 1,
      size: 10,
      distance: 80,
      autoFill: false,
      bottomStatus: '',
      allowPull: false,
      doneMore: '没有更多数据',
      id: ''
    }
  },
  mounted () {
    var _this = this
    _this.getHosDetailData(_this.$route.query.hosId)
    setTimeout(function () {
      _this.schoolId = _this.hosDetail.schoolId
      _this.getCourseListData()
    }, 300)
  },
  methods: {
    gocourseData (signInStatus, queId, scheduleId) {
      if (signInStatus === 1) {
        this.getCourseDetail(queId, scheduleId)
      } else {
        this.$toast({
          message: '签到成功后才可以答题哈',
          position: 'bottom',
          duration: 3000
        })
      }
    },
    // 获取医院信息
    getHosDetailData (hosId) {
      this.$store.dispatch('getHosDetail', { hosId: hosId, vue: this })
    },
    // 获取列表
    async getCourseListData () {
      await this.$store.dispatch('courseTestList', { schoolId: this.schoolId, page: this.page, size: this.size, _this: this })
      if (this.courseList.dt.totalCount <= this.courseList.dt.list.length) {
        this.allowPull = true
      }
    },
    // 获取详情
    getCourseDetail (queId, scheduleId) {
      fetch({
        headers: {
          'clazz': 'getQueInfo',
          'packagz': 'school'
        },
        url: '/babyapi/api/v1/school/center',
        mothod: 'get',
        params: {
          queId: queId,
          scheduleId: scheduleId
        },
        success: (res) => {
          if (res.data.code === 0) {
            let qFinish = res.data.data.hasAnswer === 'N' ? 0 : 1
            window.location.href = domain.url + '/fuerhos/school/questions/detail.html?fm=1&qFinish=' + qFinish + '&scheduleId=' + scheduleId + '&queId=' + queId
          }
        },
        fail: (err) => {
          console.log(err)
        }
      })
    },
    loadBottom () {
      var _this = this
      _this.page = _this.page + 1
      _this.getCourseListData()
    },
    formateTime (beginStr, endStr) {
      if (beginStr > 0) {
        var obj = new Date(beginStr)
        var endObj = new Date(endStr)
        return obj.getFullYear() + '-' + ((obj.getMonth() + 1).toString().length === 2 ? (obj.getMonth() + 1) : '0' + (obj.getMonth() + 1)) + '-' + (obj.getDate().toString().length === 2 ? obj.getDate() : '0' + obj.getDate()) + ' ' + (obj.getHours().toString().length === 2 ? obj.getHours() : '0' + obj.getHours()) + ':' + (obj.getMinutes().toString().length === 2 ? obj.getMinutes() : '0' + obj.getMinutes()) + '-' + (endObj.getHours().toString().length === 2 ? endObj.getHours() : '0' + endObj.getHours()) + ':' + (endObj.getMinutes().toString().length === 2 ? endObj.getMinutes() : '0' + endObj.getMinutes())
      } else {
        return ''
      }
    }
  }
}
</script>
