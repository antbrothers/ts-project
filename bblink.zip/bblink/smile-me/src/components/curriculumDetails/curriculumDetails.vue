<template>
<div class="page">
  <div class="file">
    <img :src="spot" style="display:none">
    <img :src="schedule.coursePhoto"/>
    <div class="mark">{{schedule.gestationalType}}</div>
    <div class="courseware" @click="coursewareSpot"><a :href="schedule.wareUrl"><img src="../../assets/img/Group3.png" /></a><br/><br/>
    <span>查看课件</span>
    </div>
  </div>
  <div class="bac file-detailed">
    <div class="file-other">
    <div class="detailed-title">{{schedule.courseName}}</div>
    <div class="font-28"><span>时间：</span>{{mounth(schedule.startTime)}}/{{day(schedule.startTime)}}  {{week(schedule.startTime)}}  {{formateTime(schedule.startTime,schedule.endTime)}}</div>
    <div class="font-28 mar-div"><span>地点：</span>{{schedule.classroomName}}</div>
    </div>
    <div class="file-hospital" @click="goHospitial(schedule.hosId)">
    <div class="hospital-left">
      <div class="hospital-title">{{schedule.hosName}}</div><br/>
      <div class="hospital-address">{{schedule.hosAddr}}</div>
    </div>
    <div class="hospital-right">
      <img src="../../assets/img/right-icon.png" />
    </div>
  </div>
  </div>
  <!-- <div class="bacdiv"></div> -->
  <div class="file-lecturer">
    <div class="title-line">讲师介绍</div>
    <div class="bac lecturer-list">
      <div class="doctor" v-for="(item,index) in schedule.lecturerList" :key="index" @click="goHomepage(item.doctorId)">
        <div class="doctor-img"><img :src="item.photo"/></div>
        <div class="doctor-title">
          <div class="marginb-24">
            <span class="font-32 margin-18">{{item.lecturerName}}</span>
            <span class="font-24">{{item.titleName}}</span>
          </div>
          <div class="marginb-20">
            <div class="font-28 lecturerIntro">{{item.lecturerIntro}}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="file-curriculum">
    <div class="title-line">课程简介</div>
    <div class="curriculum">
      <p>{{schedule.courseIntro}}</p>
    </div>
  </div>
  <div class="bottom_div"></div>
  <div v-if="schedule.status == 1" class="bottom remind" @click="classRemind">
    上课提醒
  </div>
  <div v-if="schedule.status == 2" class="bottom remind" @click="closeClassRemind">
    关闭提醒
  </div>
  <div v-if="schedule.status == 3" class="bottom remind" @click="signIn">
    扫码签到
  </div>
  <div v-if="schedule.status == 4" class="bottom">
    <div class="bottom-left" @click="spotUp"> <img src="../../assets/img/zancopy4.png" />赞</div>
    <div class="bottom-right font-c9">已签到</div>
  </div>
  <div v-if="schedule.status == 5" class="bottom">
    <div class="bottom-left zan" @click="spotUp"> <img src="../../assets/img/zancopy6.png" />赞</div>
    <div class="bottom-right font-c9">已签到</div>
  </div>
  <div v-if="schedule.status == 6" class="bottom end font-c9">
    已结束
  </div>
  <!-- <div class="bottom end">
    已结束
  </div>
  <div class="bottom">
    <div class="bottom-left"> <img src="../../assets/img/zancopy4.png" />赞 33</div>
    <div class="bottom-right">已签到</div>
  </div> -->
</div>
</template>
<script>
import { tool } from '../../common/util'
import { fetch } from '../../common/fetch'
import { mapState } from 'vuex'
import { Toast } from 'mint-ui'
import wx from 'weixin-js-sdk'
import { domain } from '../../common/domain'
export default {
  computed: {
    ...mapState({
      schedule: state => state.curriculum.data
    })
  },
  data () {
    return {
      spot: '',
      openId: ''
    }
  },
  mounted () {
    // this.wxccc()
    this.getschedule()
    this.openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
    this.spot = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=4-hos-schoolcourse-info&open_id=' + this.openId + '&course_id=' + this.$route.query.courseId + '&service_id=&doctor_id='
  },
  methods: {
    // 医院详情
    goHospitial (hosId) {
      console.log(hosId)
      this.$router.push({path: '/hospitalhome', query: {id: hosId}})
    },
    // 返回时间
    too (time) {
      if (time > 0) {
        return tool.dateFormat(new Date(time))
      } else {
        return ''
      }
    },
    // 月
    mounth (time) {
      if (time > 0) {
        var date = new Date(time)
        var M = date.getMonth() + 1
        return M
      } else {
        return ''
      }
    },
    // 日
    day (time) {
      if (time > 0) {
        var date = new Date(time)
        var D = date.getDate()
        return D
      } else {
        return ''
      }
    },
    // 小时
    hour (time) {
      if (time > 0) {
        var date = new Date(time)
        // () % 24 === 0 ? 0 : date.getHours() % 24
        var H = date.getHours
        if (H < 10) { H = '0' + H }
        console.log(H)
        return H
      } else {
        return ''
      }
    },
    //  (date.getMinutes() <10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
    minutes (time) {
      if (time > 0) {
        var date = new Date(time)
        var m = date.getMinutes()
        if (m < 10) { m = '0' + m }
        return m
      } else {
        return ''
      }
    },
    // 周
    week (time) {
      var date = new Date(time).getDay()
      var week
      if (time > 0) {
        switch (date) {
          case 0:
            week = '周日'
            break
          case 1:
            week = '周一'
            break
          case 2:
            week = '周二'
            break
          case 3:
            week = '周三'
            break
          case 4:
            week = '周四'
            break
          case 5:
            week = '周五'
            break
          case 6:
            week = '周六'
            break
        }
        return week
      } else {
        return ''
      }
    },
    // 查看课件打点
    coursewareSpot () {
      this.spot = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=4-hos-school-courseware-click&open_id=' + this.openId + '&course_id=' + this.$route.query.courseId + '&service_id=&doctor_id='
    },
    // 查询课程详情
    getschedule () {
      this.$store.dispatch('getScheduleDetail', {scheduleId: this.$route.query.scheduleId})
    },
    // 医生主页
    goHomepage (doctorId) {
      this.spot = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=4-hos-school-lecturerinfo-click&open_id=' + this.openId + '&course_id=' + this.$route.query.courseId + '&service_id=&doctor_id=' + doctorId
      window.location.href = domain.url + '/#/doctorHomepage?doctorId=' + doctorId
    },
    // 上课提醒
    classRemind () {
      // 4-hos-school-remind-click
      this.spot = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=4-hos-school-remind-click&open_id=' + this.openId + '&course_id=' + this.$route.query.courseId + '&service_id=&doctor_id='
      fetch({
        headers: {
          'clazz': 'setRemind',
          'packagz': 'school'},
        url: '/babyapi/api/v1/school/center',
        method: 'get',
        params: {
          scheduleId: this.$route.query.scheduleId
        },
        success: (res) => {
          if (res.data.code === 0) {
            this.schedule.status = 2
            Toast({
              message: '上课前一天8点为您短信提醒。再次点击取消提醒',
              position: 'bottom',
              duration: 5000
            })
          }
        },
        fail: function (err) {
          console.log(err)
        }
      })
    },
    // 关闭上课提醒
    closeClassRemind () {
      fetch({
        headers: {
          'clazz': 'cancelRemind',
          'packagz': 'school'},
        url: '/babyapi/api/v1/school/center',
        method: 'get',
        params: {
          scheduleId: this.$route.query.scheduleId
        },
        success: (res) => {
          this.schedule.status = 1
          if (res.data.code === 0) {
            Toast({
              message: '取消成功',
              position: 'bottom',
              duration: 3000
            })
          }
        },
        fail: function (err) {
          console.log(err)
        }
      })
    },
    // 点赞和取消点赞
    spotUp () {
      // 4-hos-school-praise-click
      this.spot = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=4-hos-school-praise-click&open_id=' + this.openId + '&course_id=' + this.$route.query.courseId + '&service_id=&doctor_id='
      var status = this.schedule.status === '4' ? 1 : 0
      fetch({
        headers: {
          'clazz': 'cancelRemind',
          'packagz': 'school'},
        url: '/babyapi/api/school/v1.3/updatePraise',
        method: 'post',
        data: {
          scheduleId: this.$route.query.scheduleId,
          status: status
        },
        success: (res) => {
          this.schedule.status = status === 1 ? '5' : '4'
        },
        fail: function (err) {
          console.log(err)
        }
      })
    },
    formateTime (beginStr, endStr) {
      if (beginStr > 0) {
        var obj = new Date(beginStr)
        var endObj = new Date(endStr)
        return (obj.getHours().toString().length === 2 ? obj.getHours() : '0' + obj.getHours()) + ':' + (obj.getMinutes().toString().length === 2 ? obj.getMinutes() : '0' + obj.getMinutes()) + '-' + (endObj.getHours().toString().length === 2 ? endObj.getHours() : '0' + endObj.getHours()) + ':' + (endObj.getMinutes().toString().length === 2 ? endObj.getMinutes() : '0' + endObj.getMinutes())
      } else {
        return ''
      }
    },
    // 签到
    signIn () {
      // 4-hos-school-signin-click
      this.spot = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=4-hos-school-signin-click&open_id=' + this.openId + '&course_id=' + this.$route.query.courseId + '&service_id=&doctor_id='
      fetch({
        url: '/api/User/Wechat/jssdk',
        method: 'get',
        params: {
          'url': location.href.split('#')[0],
          // 测试
          //  'appId': 'wx5fbc1df873478202'
          // 正式
          'appId': domain.appId
        },
        success: (res) => {
          if (res.status === 200) {
            let jsonData = res.data.data
            if (!jsonData.appid) return
            wx && wx.config({
              debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
              appId: jsonData.appid, // 必填，公众号的唯一标识
              timestamp: jsonData.timeStamp, // 必填，生成签名的时间戳
              nonceStr: jsonData.nonceStr, // 必填，生成签名的随机串
              signature: jsonData.signature, // 必填，签名，见附录1
              jsApiList: [
                'checkJsApi',
                'onMenuShareTimeline',
                'onMenuShareAppMessage',
                'scanQRCode',
                'hideAllNonBaseMenuItem',
                'showAllNonBaseMenuItem',
                'hideMenuItems',
                'showMenuItems',
                'hideOptionMenu',
                'showOptionMenu',
                'onMenuShareTimeline',
                'onMenuShareAppMessage',
                'onMenuShareQQ',
                'onMenuShareWeibo',
                'onMenuShareQZone'
              ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
            })
          }
        }
      })
      wx.error(function (res) {
        alert('出错了：' + res.errMsg)// 这个地方的好处就是wx.config配置错误，会弹出窗口哪里错误，然后根据微信文档查询即可。
      })
      wx.ready(function () {
        wx.checkJsApi({
          jsApiList: ['scanQRCode'],
          success: function (res) {
          }
        })
        // 点击按钮扫描二维码
        wx.scanQRCode({
          needResult: 0, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
          scanType: ['qrCode'], // 可以指定扫二维码还是一维码，默认二者都有
          success: function (res) {
            // console.log(res)
            // if (res.errMsg === 'scanQRCode:ok') {
            //   window.location.href = res.resultStr
            // }
          }
        })
      })
    }
  }
}
</script>
<style scoped>
.page{
  width: 100%;
  background: #f4f4f4;
}
.bac{
  background:#FFFFFF;
  padding-left: 24px;
  padding-right: 24px;
}
.file{
  position: relative;
  height: 400px;
  /* float: left; */
}
.file img{
  width: 100%;
  height: 400px;
}
.mark{
  min-width: 100px;
  margin-top:-360px;
  float: right;
  position:relative;
  height: 48px;
  line-height: 48px;
  background: url("../../assets/img/biaoqian.png");
  background-size: 100% 100%;
  text-align: center;
  padding-right: 10px;
  padding-left: 30px;
  color: #ffffff;
  font-size: 24px;
}
.courseware{
  position:relative;
  margin-top:-260px;
  text-align: center;
}
.courseware img{
  width: 120px;
  height: 120px;
}
.courseware span{
  color: #ffffff;
  margin-top: 35px;
  font-size: 28px;
}
.file-detailed{
  /* float: left; */
  padding-top: 24px;
  margin-bottom: 20px;
}
.file-other{
  /* height: 242px; */
  border-bottom: 1px solid #dddddd;
}
.detailed-title{
  font-size: 36px;
  margin-bottom: 38px;
}
.font-28{
  color: #999999;
  font-size: 28px;
}
.mar-div{
  padding-top:26px;
  padding-bottom: 38px;
}
.file-hospital{
  height: 152px;
  padding-bottom: 15px;
}
.file-hospital div{
  display: inline;
}
.hospital-left div{
  display: inline-block;
  vertical-align: middle;
  line-height: 70px;
}
.hospital-title{
  margin-top: 15px;
  font-size: 32px;
}
.hospital-address{
  font-size: 28px;
  color: #999999;
  width: 600px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.hospital-right img{
  width: 16px;
  height: 26px;
}
.hospital-right{
  margin-top: -20px;
  float: right;
  height: 152px;
}
.bacdiv{
  /* float: left; */
  width: 100%;
  height: 24px;
  background: #f4f4f4;
}
.file-lecturer{
  /* float: left; */
  width: 100%;
  margin-bottom: 20px;
}
.title-line{
  height: 88px;
  line-height: 88px;
  border-bottom: solid #DDDDDD 1px;
  padding-left: 20px;
  font-size: 30px;
  background-color: #FFFFFF;
}
.doctor{
  height: 190px;
  display:flex;
  /* justify-content:center; */
  align-items:center;
  border-bottom: solid #DDDDDD 1px;
}
.doctor-img{
  display:inline-block;
  /* float: left; */
  vertical-align: middle;
  padding-left: 22px;
  border-radius: 100%;
}
.doctor-img img{
  border-radius: 100%;
  width: 100px;
  height: 100px;
  vertical-align: middle;
}
.doctor-title{
  display:inline-block;
  /* float: left; */
  margin-left: 24px;
}
.font-32{
  font-size: 32px;
}
.font-24{
  font-size: 24px;
}
.font-28{
  font-size: 28px;
}
.margin-18{
  margin-right: 18px;
}
.margin-20{
  margin-right: 20px;
}
.marginb-24{
  padding-top: 38px;
  margin-bottom: 18px;
}
.marginb-20{
  margin-bottom: 24px;
}
.doctor-right{
  height: 160px;
  line-height: 160px;
  margin-left: 70px;
}
.doctor-right img{
  width: 40px;
  height: 40px;
}
.file-curriculum{
  width: 100%;
  height: 292px;
  /* float: left; */
}
.curriculum{
  padding: 25px;
  background-color: #ffffff;
}
.bottom_div{
  width: 100%;
  height: 98px;
  margin-top: 50px;
}
.bottom {
  width: 100%;
  height: 98px;
  line-height: 98px;
  position: fixed;
  bottom: 0px;
  text-align: center;
}
.remind{
  background: #FF7070;
  color: #ffffff;
  font-size: 32px;
}
.end{
  background: #DFDFDF;
  color: #999999;
  font-size: 32px;
}
.bottom-left{
  float: left;
  display:inline-block;
  width: 375px;
  font-size: 28px;
  background-color: #ffffff;
}
.bottom-left img{
  widows: 30px;
  height: 30px;
  padding-right: 20px;
}
.bottom-right{
  display: inline-block;
  background: #DFDFDF;
  width: 375px;
  font-size: 28px;
}
.zan{
  color: #FF7070;
}
.doctor-introduce{
  overflow:hidden;
  text-overflow:ellipsis;
  display:-webkit-box;
  -webkit-box-orient:vertical;
  -webkit-line-clamp:2;
}
.curriculum p{
  font-size: 28px;
  color: #888888;
}
.end{
  background-color: #DFDFDF;
}
.lecturerIntro{
  overflow:hidden;
  text-overflow:ellipsis;
  display:-webkit-box;
   /* autoprefixer: off */
  -webkit-box-orient:vertical;
  /* autoprefixer: on */
  -webkit-line-clamp:2;
}
.font-c9{
  color: #999999;
}
</style>
