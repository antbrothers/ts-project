<template>
  <div id="hospita-home">
    <img class="banner" src="../../assets/img/Bitmap@2x.png" alt="">
    <!-- <img class="banner" :src="hosDetials.photo" alt=""> -->
    <div class="hospita-info">
      <div style="width:100%">
        <div class="hospita-name">{{hosDetials.hosName}}</div>
        <div class="hospita-info-main">
          <div class="hospita-info-con">
            <div class="hospita-grade" v-if="hosDetials.level">{{hosDetials.level}}</div>
            <span class="year-name">年分娩量:</span>
            <span class="year-num">{{hosDetials.birthNum}}</span>
          </div>
          <div class="hospita-profiles" @click="profiles">简介</div>
        </div>
      </div>
    </div>
    <div class="hospita-address" @click='goNavigation(hosDetials.hosName, hosDetials.cityName, hosDetials.countyName, hosDetials.addr)'>
      <div class="address-info">
        <img class="map-icon" src="../../assets/img/icon_dizhi@2x.png" alt="">
        <span class="address-name">{{hosDetials.addr}}</span>
      </div>
      <img class="right-icon" src="../../assets/img/right-icon.png" alt="">
    </div>
    <div class="hospita-tel" @click='showphone'>
      <img class="tel-icon" src="../../assets/img/icon_dianhua@2x.png" alt="">
      <span class="tel-text">联系方式</span>
      <span class="tel-more">{{hosDetials.tel}}</span>
    </div>
    <div class="bg" v-if="swiperNum > 0"></div>
    <div id="banner-swiper" class="banner-swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide" v-if="school">
          <div class="swiper-banner" @click="hosSchool">
            <img class="swiper-banner-img" src="../../assets/img/yfxx@2x.png" alt="">
            <div class="swiper-banner-name">孕妇学校</div>
            <div class="swiper-banner-text">课表签到学习</div>
          </div>
        </div>
        <div class="swiper-slide" v-if="guahao">
          <div class="swiper-banner" @click="hosGuahao">
            <img class="swiper-banner-img" src="../../assets/img/ghyy@2x.png" alt="">
            <div class="swiper-banner-name">预约挂号</div>
            <div class="swiper-banner-text">免排队快速预约</div>
          </div>
        </div>
        <div class="swiper-slide" v-if="wenzhen">
          <div class="swiper-banner" @click="hosWenzhen">
            <img class="swiper-banner-img" src="../../assets/img/zxwz@2x.png" alt="">
            <div class="swiper-banner-name">在线问诊</div>
            <div class="swiper-banner-text">名医在线咨询</div>
          </div>
        </div>
        <div class="swiper-slide" v-if="inquiry">
          <div class="swiper-banner" @click="hosInquiry">
            <img class="swiper-banner-img" src="../../assets/img/zbmz@2x.png" alt="">
            <div class="swiper-banner-name">专病门诊</div>
            <div class="swiper-banner-text">诊疗更精准</div>
          </div>
        </div>
        <div class="swiper-slide" v-if="bigcard">
          <div class="swiper-banner" @click="hosBigcard">
            <img class="swiper-banner-img" src="../../assets/img/dkyy@2x.png" alt="">
            <div class="swiper-banner-name">大卡预约</div>
            <div class="swiper-banner-text">完善资料轻松建卡</div>
          </div>
        </div>
        <div class="swiper-slide" v-if="coursetest">
           <!-- @click="hosCoursetest" -->
          <div class="swiper-banner">
            <img class="swiper-banner-img" src="../../assets/img/stcs@2x.png" alt="">
            <div class="swiper-banner-name">随堂测试</div>
            <div class="swiper-banner-text">做满分父母</div>
          </div>
        </div>
      </div>
      <div class="swiper-pagination" v-if="swiperNum > 3"></div>
    </div>
    <div class="bg" v-if="swiperNum > 0"></div>
    <div id="expert" v-if="expertList.length > 0">
      <div class="title-main">
        <div class="title-name">专家服务</div>
        <div class="title-more" @click="expertMore">
          <span>查看更多</span>
          <img class="right-icon" src="../../assets/img/right-icon.png" alt="">
        </div>
      </div>
      <div class="swiper-container">
        <div class="swiper-wrapper">
          <div class="swiper-slide" v-for="(item, index) in expertList" :key="item.providerId" :class="(index + 1) == expertList.length ? 'expert-last' : '' "  @click="expertDoctor(item)">
            <div class="expert-main">
              <img class="expert-img" :src="item.photo ? item.photo : 'https://image.bblink.cn/moren.png'" alt="">
              <div class="expert-info">
                <div class="expert-name">{{item.doctorName}}</div>
                <div class="expert-grade">{{item.titleName}}</div>
              </div>
            </div>
            <div class="expert-btn">找TA服务</div>
          </div>
        </div>
      </div>
    </div>
    <div class="bg" v-if="expertList.length > 0"></div>
    <div id="classroom" v-if="classroomList.length > 0">
      <div class="title-main">
        <div class="title-name">云课堂</div>
        <div class="title-more" @click="cloudClass">
          <span>查看更多</span>
          <img class="right-icon" src="../../assets/img/right-icon.png" alt="">
        </div>
      </div>
      <div class="classroom-main">
        <div class="classroom-info" v-for="item in classroomList" :key="item.courseId" @click="classroomDetail(item)">
          <img class="classroom-img" :src="item.picUrl" alt="">
          <div class="classroom-text">{{item.name}}</div>
          <!-- <div class="classroom-price">90</div> -->
        </div>
      </div>
    </div>
    <div class="bg" v-if="classroomList.length > 0"></div>
    <div id="member" v-if="memberList.length > 0">
      <div class="title-main">
        <div class="title-name">会员服务</div>
      </div>
      <div v-for="(item, index) in memberList" :key="item.img" @click="memberService(item)">
        <div class="member-main">
          <img class="member-img" src="../../assets/img/vip-service.jpg" alt="">
          <div class="member-info">
            <div class="member-name">{{item.name}}</div>
            <div class="member-price">￥{{item.price/100}}</div>
          </div>
        </div>
        <div class="member-label" :class="(index + 1) == memberList.length ? 'last-label' : '' ">
          <div v-for="(labelItem, labelIndex) in item.serviceList" :key="labelIndex">
            <div class="label">{{labelItem.name}}</div>
          </div>
        </div>
      </div>
    </div>
    <mt-popup v-model="phoneModels" position="bottom" class='phoneModels'>
      <div v-for="(item, index) in hosTel" :key="index">
        <a :href="'tel://' + item" class='telll'>
          <img class="tel-img" src="../../assets/img/tel.png" alt="">
          <span>{{item}}</span>
        </a>
      </div>
      <div @click='closephone'>取消</div>
    </mt-popup>
    <img :src="spotSrc" alt="" style="display:none;">
  </div>
</template>
<script>
import { mapState } from 'vuex'
import { domain } from '../../common/domain'
export default {
  computed: {
    ...mapState({
      hosDetials: state => state.hosDetail.dt,
      hosTel: state => state.hosDetail.tel,
      hosList: state => state.hospitalHome.hosHomeList
    })
  },
  data () {
    return {
      phoneModels: false,
      // hosService: [],
      school: false,
      inquiry: false,
      bigcard: false,
      coursetest: false,
      guahao: false,
      wenzhen: false,
      expertList: [],
      classroomList: [],
      memberList: [],
      spotSrc: '',
      swiperNum: 0,
      id: ''
    }
  },
  mounted () {
    this.getHosDetail()
    this.hosHomeList()
    this.hosHompage({log_type: '2-hos-hompage', doctor_id: '', course_id: '', service_id: ''})
  },
  methods: {
    // 获取医院详情·
    async getHosDetail () {
      let _this = this
      let obj = null
      if (this.$route.query.id) {
        obj = {hosId: this.$route.query.id, vue: _this}
      } else {
        obj = {schoolId: this.$route.query.schoolId, vue: _this}
      }
      await _this.$store.dispatch('getHosDetail', obj)
      _this.hosDetials.hosServiceVos.forEach(function (value, index) {
        if (value.serviceName === 'SCHOOL') {
          _this.swiperNum++
          _this.school = true
        } else if (value.serviceName === 'INQUIRY') {
          _this.swiperNum++
          _this.inquiry = true
        } else if (value.serviceName === 'BIGCARD') {
          _this.swiperNum++
          _this.bigcard = true
        } else if (value.serviceName === 'COURSETEST') {
          _this.swiperNum++
          _this.coursetest = true
        } else if (value.serviceName === 'GUAHAO') {
          _this.swiperNum++
          _this.guahao = true
        } else if (value.serviceName === 'WENZHEN') {
          _this.swiperNum++
          _this.wenzhen = true
        }
      })
      setTimeout(function () {
        _this.bannerSwiper()
      }, 0)
    },
    async hosHomeList () {
      let _this = this
      let obj = null
      if (this.$route.query.id) {
        obj = {hosId: this.$route.query.id}
      } else {
        obj = {schoolId: this.$route.query.schoolId}
      }
      await _this.$store.dispatch('hosHomeList', obj)
      _this.expertList = _this.hosList.doctorList
      _this.$nextTick(function () {
        _this.expertSwiper()
      })
      _this.classroomList = _this.hosList.cloudCourseList
      _this.memberList = _this.hosList.serviceCardList
    },
    bannerSwiper () {
      let _this = this
      /* eslint-disable */
      var bannerSwiper = new Swiper ('.banner-swiper-container', {
        loop: _this.swiperNum > 3,
        loopFillGroupWithBlank: true,
        slidesPerView : 3,
        slidesPerGroup : 3,
        allowSwipeToPrev : true,
        // 如果需要分页器
        pagination: {
          el: '#banner-swiper .swiper-pagination',
          bulletActiveClass: 'my-bullet-active'
          
        },        
        on:{
          click: function(){
            if (this.clickedSlide.innerText.indexOf('随堂测试') !== -1) {
              _this.hosHompage({log_type: '2-hos-test-click', doctor_id: '', course_id: '', service_id: ''})
              _this.$router.push({path: '/sweetown?hosId=' + _this.id})
            }
          }
        }
      })
    },
    expertSwiper () {
      var expertSwiper = new Swiper('.swiper-container', {
        slidesPerView :'auto',
        freeMode: true
      })
    },
    // 简介
    profiles () {
      this.$router.push({path: '/hospitialDetail?hosId=' + this.id})
    },
    // 孕妇学校
    hosSchool () {
      this.hosHompage({log_type: '2-hos-pregn-school-click', doctor_id: '', course_id: '', service_id: ''})
      this.$router.push({path: '/pregnantwomen?hosId=' + this.id})
    },
    // 挂号预约
    hosGuahao () {
      this.hosHompage({log_type: '2-hos-reservation-click', doctor_id: '', course_id: '', service_id: ''})
    },
    // 在线问诊
    hosWenzhen () {
      this.hosHompage({log_type: '2-hos-online-inquiry-click', doctor_id: '', course_id: '', service_id: ''})
    },
    // 专病门诊
    hosInquiry () {
      this.hosHompage({log_type: '2-hos-specialist-clinic-click', doctor_id: '', course_id: '', service_id: ''})
      this.$router.push({path: '/menzhen?hosId=' + this.id})
    },
    // 大卡预约
    hosBigcard () {
      this.hosHompage({log_type: '2-hos-archives-click', doctor_id: '', course_id: '', service_id: ''})
      window.location.href = domain.url + '/#/archives/bespeak'
    },
    // 随堂测试
    hosCoursetest () {
      this.hosHompage({log_type: '2-hos-test-click', doctor_id: '', course_id: '', service_id: ''})
      this.$router.push({path: '/sweetown?hosId=' + this.id})
    },
    // 专家服务-->查看更多
    expertMore () {
      this.$router.push({path: '/doctorslist?hosId=' + this.id})
    },
    // 专家服务-->医生头像及找TA服务
    expertDoctor (row) {
      this.hosHompage({log_type: '3-hos-serv-doctor-click', doctor_id: row.providerId, course_id: '', service_id: ''})
      window.location.href = domain.url + `/#/doctorHomepage?doctorCode=${row.accountNo}&doctorId=${row.providerId}&source=5`
    },
    // 云课堂查看更多
    cloudClass () {
      this.$router.push({path: '/cloudclass?hosId=' + this.id})
    },
    // 云课堂-->列表点击头像
    classroomDetail (row) {
      this.hosHompage({log_type: '3-hos-online-course-click', doctor_id: '', course_id: '', service_id: ''})
      if (row.courseType === 1) { // 精选好课
        window.location.href = domain.url + `/#/school/expert-detail?courseId=${row.courseId}`
      } else { // 主题系列课
        window.location.href = domain.url + `/#/school/academy-detail?courseId=${row.courseId}`
      }
    },
    // 会员服务
    memberService (row) {
      this.hosHompage({log_type: '2-hos-servcard-click', doctor_id: '', course_id: '', service_id: row.code})
      window.location.href = domain.url + `/#/serviceCard/serviceCard-details1?packCode=${row.code}&source=4&hosId=${this.id}`
    },
    // 电话下拉显示隐藏
    showphone () {
      if (this.hosDetials.tel.length > 0) {
        this.phoneModels = true
      }
      this.hosHompage({log_type: '2-hos-contact-click', doctor_id: '', course_id: '', service_id: ''})
    },
    closephone () {
      this.phoneModels = false
    },
    // 跳转至导航页
    goNavigation (hosName, cityName, countyName, address) {
      this.hosHompage({log_type: '2-hos-address-click', doctor_id: '', course_id: '', service_id: ''})
      let addr = cityName + countyName + address
      location.href = domain.url + '/#/hospital/details/navigation?hosName=' + hosName + '&address=' + addr
    },
    // 打点
    hosHompage (row) {
      let hos_id = ''
      let school_id = ''
      if (this.$route.query.id) {
        hos_id = this.$route.query.id
      } else {
        school_id = this.$route.query.schoolId
      }
      let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
      this.spotSrc = `https://wifi.bblink.cn/springrx/getWemaPoint?log_type=${row.log_type}&open_id=${openId}&hos_id=${hos_id}&school_id=${school_id}&service_id=${row.service_id}&doctor_id=${row.doctor_id}`
    }
  }
}
</script>
<style lang="less" scoped>
#hospita-home {
  .phoneModels {
    width:100%;
    background: #fff;
    font-size: 30px;
    div {
      height: 90px;
      box-sizing: border-box;
      line-height: 90px;
      text-align: center;
      border-top:1px solid #ddd;
      color:#333;
      .telll {
        color:#333;
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration:none;
        .tel-img {
          width: 28px;
          height: 28px;
          margin-right: 12px;
        }
      }
    }
  }
}
.banner {
  width: 100%;
  height: 240px;
  vertical-align: bottom;
}
.right-icon {
  width: 15px;
  height: 24px;
}
.hospita-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 24px 18px 24px 0;
  margin-left: 20px;
  position: relative;
  // border-bottom: 1px solid #dddddd;
  &:before {
    content: '';
    width: 200%;
    height: 200%;     
    position: absolute;
    top: 0;
    left: 0;
    border-bottom: 1px solid #dddddd; /* no */
    transform: scale(0.5);
    transform-origin: 0 0;    
    box-sizing: border-box;
    pointer-events: none;      
  }
  .hospita-name {
    max-height: 100px;
    font-size: 36px;
    font-weight: bold;
  }
  .hospita-info-main {
    width: 100%;
    display: flex;
    align-items: center;
    font-size: 24px;
    margin-top: 24px;
    justify-content: space-between;
    .hospita-grade {
      color: #FF7070;
      font-size: 20px;
      // width: 100px;
      height: 30px;
      line-height: 32px;
      margin-right: 20px;
      border-radius:30px;
      text-align: center;
      border: 2px solid #FF7070;
      padding: 2px 10px 0 10px;
    }
    .year-name {
      height: 32px;
      display: flex;
      align-items: center;
    }
    .year-num {
      // display: block;
      height: 32px;
      // padding: 7px 0 2px;
      // line-height: 24px;
      margin-left: 10px;
      display: flex;
      align-items: center;
      // line-height: 30px;
      margin-top: 1px;
    }
  }
  .hospita-info-con {
    color: #999999;
    display: flex;
    align-self: center;
  }
  .hospita-profiles {
    font-size: 28px;
    color: #8AB1FF;
  }
}
.hospita-address {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-left: 24px;
  padding: 24px 22px 28px 0;
  // border-bottom: 1px solid #dddddd;
  position: relative;
  &:before {
    content: '';
    width: 200%;
    height: 200%;     
    position: absolute;
    top: 0;
    left: 0;
    border-bottom: 1px solid #dddddd; /* no */
    transform: scale(0.5);
    transform-origin: 0 0;    
    box-sizing: border-box;
    pointer-events: none;      
  }
  .address-info {
    display: flex;
    align-items: center;
  }
  .map-icon {
    width: 26px;
    height: 32px;
    margin-right: 30px;
  }
  .address-name {
    display: block;
    width: 616px;
    font-size: 28px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
}
.hospita-tel {
  display: flex;
  align-items: center;
  margin-left: 24px;
  padding: 24px 22px 28px 0;
  color: #999999;
  font-size: 28px;
  .tel-icon {
    width: 26px;
    height: 32px;
  }
  .tel-text {
    margin: 0 24px 0 30px;
    color: #333333;
  }
  .tel-more {
    display: block;
    width: 500px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
}
.bg {
  width: 100%;
  height: 20px;
  background-color: #F4F4F4;
}
.swiper-main {
  display: flex;
  justify-content: space-around;
  padding: 42px 0 64px;
}
.swiper-banner {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 42px 0 64px;
  .swiper-banner-img {
    width: 88px;
    height: 88px;
    border-radius: 50%;
    vertical-align: bottom;
  }
  .swiper-banner-name {
    font-size: 28px;
    margin-top: 22px;
  }
  .swiper-banner-text {
    color: #999999;
    font-size: 24px;
  }
}
.title-main {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 32px 21px 40px 20px;
  .title-name {
    font-size: 32px;
  }
  .title-more {
    font-size: 24px;
    color: #999999;
    display: flex;
    align-items: center;
    .right-icon {
      margin-left: 12px;
    }
  }
}
#expert {
  .swiper-slide {
    width: 260px;
    height: 214px;
    margin-left: 40px;
    margin-bottom: 40px;
    // border-right: 1px solid #dddddd;
    position: relative;
    &:before {
      content: '';
      width: 200%;
      height: 200%;
      position: absolute;
      top: 0;
      left: 0;
      border-right: 1px solid #dddddd; /* no */
      transform: scale(0.5);
      transform-origin: 0 0;
      box-sizing: border-box;
      pointer-events: none;
    }
    .expert-main {
      display: flex;
      align-items: center;
      .expert-img {
        width: 100px;
        height: 100px;
        border-radius: 50%;
      }
      .expert-info {
        // display: flex;
        // flex-direction: column;
        // align-items: center;
      }
      .expert-name {
        width: 130px;
        font-size: 28px;
        padding: 12px 0 10px 20px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .expert-grade {
        width: 130px;
        color: #999999;
        font-size: 24px;
        padding: 0 0 0 22px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
    .expert-btn {
      width: 224px;
      height: 18px;
      color: white;
      font-size: 27px;
      border-radius: 31px;
      background-color: #FEC963;
      text-align: center;
      // padding-top: 2px;
      line-height: 20px;
      margin-top: 40px;
      margin-bottom: 54px;
      padding: 22px 0 20px; 
    }
  }
  .expert-last {
    width: 261px;
    border-right: 0;
    &:before {
      content: '';
      width: 200%;
      height: 200%;
      position: absolute;
      top: 0;
      left: 0;
      border-right: 1px solid #dddddd; /* no */
      transform: scale(0.5);
      transform-origin: 0 0;
      box-sizing: border-box;
      pointer-events: none;
    }
  }
}
#classroom {
  .classroom-main {
    display: flex;
    // justify-content: space-between;
  }
  .classroom-info {
    width: 344px;
    margin-left: 20px;
    margin-bottom: 27px;
    .classroom-img {
      width: 344px;
      height: 174px;
      vertical-align: bottom;
    }
    .classroom-text {
      height: 42px;
      width: 344px;
      line-height: 42px;
      font-size: 30px;
      margin-bottom: 5px;
      margin-top: 15px;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
    .classroom-price {
      color: #FF7070;
      font-size: 28px;
      height: 40px;
      line-height: 40px;
    }
  }
}
#member {
  .member-main {
    display: flex;
    margin-left: 20px;
    .member-img {
      width: 256px;
      height: 146px;
      vertical-align: bottom;
    }
    .member-info {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      margin-left: 20px;
      .member-name {
        width: 370px;
        // height: 108px;
        line-height: 42px;
        font-size: 30px;
        text-overflow:ellipsis;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;  //这里是在第二行有省略号
        overflow: hidden;
      }
      .member-price {
        color: #FF7070;
        font-size: 28px;
        // margin-top: 25px;
      }
    }
  }
  .member-label {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    padding: 30px 0 30px 0;
    margin-left: 20px;
    // border-bottom: 1px solid #dddddd;
    margin-bottom: 32px;
    position: relative;
    &:before {
      content: '';
      width: 200%;
      height: 200%;
      position: absolute;
      top: 0;
      left: 0;
      border-bottom: 1px solid #dddddd; /* no */
      transform: scale(0.5);
      transform-origin: 0 0;
      box-sizing: border-box;
      pointer-events: none;
    }
    .label {
      // width: 86px;
      height: 36px;
      color: #999999;
      border-radius: 18px;
      background-color: #F0F0F0;
      text-align: center;
      line-height: 37px;
      margin: 5px;
      margin-right: 20px;
      padding: 0 14px;
      font-size: 20px;
    }
  }
  .last-label {
    border-bottom: 0px solid #dddddd;
    margin-bottom: 0;
  }
}
</style>
<style>
#banner-swiper {
  position: relative;
  width: 100%;
  overflow: hidden;
}
#banner-swiper .swiper-pagination-bullet {
  width: 14px;
  height: 6px;
  border-radius: 3px;
  background: #FF7070;
}
#banner-swiper .my-bullet-active {
  width: 30px;
  height: 6px;
  border-radius: 3px;
  background: #FF7070;
}
#banner-swiper .swiper-container-horizontal>.swiper-pagination-bullets, .swiper-pagination-custom, .swiper-pagination-fraction {
  bottom: 10px;
}
</style>

