<template>
  <div id="cloudClass">
    <div class="banner-main">
      <img class="banner" src="../../assets/img/Bitmap@2x.png" alt="">
      <!-- <img class="banner" :src="cloudClassList.bannerDate.hosPhoto" alt=""> -->
      <img class="mask" src="../../assets/img/Bitmap Copy@2x.png" alt="">
      <div class="banner-info">
        <div class="banner-name">{{cloudClassList.bannerDate.hosName}}</div>
        <div class="banner-text">已更新{{cloudClassList.bannerDate.count}}节课</div>
      </div>
    </div>
    <div class="no-data-main" v-if="cloudClassList.jxhkPage==0&&cloudClassList.themeList.length==0">
      <img src="../../assets/img/none.png" class="no-data" alt="">
      <div class="no-data-text">暂无数据</div>
    </div>
    <div class="bg" v-if="cloudClassList.jxhkPage>0"></div>
    <div class="cloudClass-title" v-if="cloudClassList.jxhkPage>0">
      <img class="title-img" src="../../assets/img/Group 9@2x.png" alt="">
      <span class="title-name">精选好课</span>
    </div>
    <div id="jxhk" v-if="cloudClassList.jxhkPage>0">
      <!-- :class="(index + 1) == cloudClassList.jxhkList.length ? 'jxhk-last' : '' " -->
      <div class="jxhk-main" @click="jxhkInfo(item)" v-for="(item, index) in cloudClassList.jxhkList" :key="item.courseId" :class="{ 'jxhk-last': (index + 1) == cloudClassList.jxhkList.length, 'jxhk-last-b': cloudClassList.jxhkPage <= 2 && (index + 1) == cloudClassList.jxhkList.length}">
        <img class="jxhk-img" :src="item.lecturerPhoto" alt="">
        <div class="jxhk-info">
          <div class="jxhk-name">{{item.name}}</div>
          <div class="doctor-info">
            <span class="doctor-name">{{item.lecturerName}}</span>
            <span>{{item.lecturerTitle}}</span>
          </div>
          <div class="hospital-name">{{item.hosName}} </div>
          <!-- 各种状态的判断 -->
          <img class="jxhk-btn" v-if="item.type==1&&item.wareType!='MP4'" src="../../assets/img/Group 4@2x.png" alt="">
          <img class="jxhk-btn" v-else-if="item.type==1&&item.wareType=='MP4'" src="../../assets/img/Group Copy@2x.png" alt="">
          <!-- <div class="label-main" v-else-if="item.type==2&&item.liveStatus==1&&item.time-7200000>0">
            <span class="live-time-title">直播时间: </span>
            <span class="live-time">{{item.lastingTime}}</span>
          </div> -->
          <!-- <div class="label-main" v-else-if="item.type==2&&item.liveStatus==1&&item.time-7200000<=0">
            <div class="label-info">
              <div class="spot"></div>
              <div class="text">即将开始</div>
            </div>
            <span class="time-title">距离开课还有：</span>
            <span class="time">{{formatDuring(item.time)}}</span>
          </div> -->
          <div class="label-main" v-else-if="item.type==2&&item.liveStatus==1&&item.time-7200000>0">
            <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
            <span class="live-time-title live-time-title1">直播时间: </span>
            <span class="live-time live-time1">{{item.lastingTime}}</span>
          </div>

          <div class="label-main" v-else-if="item.type==2&&item.liveStatus==1&&item.time-7200000<=0">
            <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
            <span class="time-title">距离开课还有：</span>
            <span class="time">{{formatDuring(item.time)}}</span>
          </div>
          <div class="label-main" v-else-if="item.type==2&&(item.liveStatus==2||item.liveStatus==6||item.liveStatus==7)">
            <!-- <div class="live-info">
              <div class="spot"></div>
              <div class="text">直播</div>
            </div> -->
            <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
            <div class="live-text">正在直播</div>
          </div>
          <div class="label-main" v-else-if="item.type==2&&(item.liveStatus==3||item.liveStatus==5)">
            <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
            <div class="playback">回放</div>
          </div>
        </div>
      </div>
    </div>
    <div class="jxhk-more" v-if="cloudClassList.jxhkPage>2" @click="cloudClassMore">查看更多</div>
    <div class="bg" v-if="cloudClassList.themeList.length>0"></div>
    <div class="cloudClass-title" v-if="cloudClassList.themeList.length>0">
      <img class="title-img" src="../../assets/img/Fill 1@2x.png" alt="">
      <span class="title-name">主题系列课</span>
    </div>
    <div id="theme" v-if="cloudClassList.themeList.length>0">
      <mt-loadmore :bottom-method="loadBottom" :bottom-all-loaded="allLoaded" ref="loadmore" :auto-fill="false" bottom-drop-text="加载更多">
        <ul>
          <li v-for="(item, index) in cloudClassList.themeList" :key="item.courseId" @click="themeInfo(item)">
            <img class="theme-img" :src="item.picUrl" alt="">
            <div class="theme-text">{{item.name}}</div>
            <div v-if="item.type==2&&item.liveStatus==1&&item.time-7200000<=0" class="theme-main" :class="(index + 1) == cloudClassList.themeList.length ? 'theme-last' : '' ">
              <div class="theme-info">
                <div class="spot"></div>
                <div class="text">即将开始</div>
              </div>
              <span class="time-title">距离开课还有：</span>
              <span class="time">{{formatDuring(item.time)}}</span>
            </div>
            <div v-else-if="item.type==2&&item.liveStatus==1&&item.time-7200000>0" class="theme-main" :class="(index + 1) == cloudClassList.themeList.length ? 'theme-last' : '' ">
              <span class="live-time-title">直播时间: </span>
              <span class="live-time">{{item.lastingTime}}</span>
            </div>
            <div v-else-if="item.type==2&&(item.liveStatus==2||item.liveStatus==6||item.liveStatus==7)" class="theme-main" :class="(index + 1) == cloudClassList.themeList.length ? 'theme-last' : '' ">
              <!-- <div class="live-info">
                <div class="spot"></div>
                <div class="text">直播</div>
              </div> -->
              <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
              <div class="live-text">正在直播</div>
            </div>
            <!-- <div class="theme-main" v-else-if="item.type==2&&(item.liveStatus==3||item.liveStatus==5)" :class="(index + 1) == cloudClassList.themeList.length ? 'theme-last' : '' ">
              <img class="jxhk-btn" src="../../assets/img/live.png" alt="">
              <div class="playback">回放</div>
            </div> -->
            <div v-else class="theme-main empty" :class="(index + 1) == cloudClassList.themeList.length ? 'theme-last' : '' "></div>
          </li>
        </ul>
      </mt-loadmore>
    </div>
    <img :src="cloudClassSrc" alt="" style="display:none;">
  </div>
</template>
<script>
import { mapState } from 'vuex'
import { domain } from '../../common/domain'
import * as types from '../../store/hospitalHome/mutationType.js'
export default {
  computed: {
    ...mapState({
      cloudClassList: state => state.hospitalHome.cloudClassList
    })
  },
  data () {
    return {
      allLoaded: false,
      page: 1,
      cloudClassSrc: ''
    }
  },
  mounted () {
    // setTimeout(function () {
    //   window.scrollTo(0, 0)
    // }, 200)
    this.$store.commit(types.DELTHEMELIST)
    this.getJxhkList()
    this.hosCourse()
    this.getThemeList()
    this.cloudClassSpot({log_type: '3-hos-onlineclass', doctor_id: '', course_id: '', service_id: ''})
  },
  methods: {
    // 精选好课
    getJxhkList () {
      this.$store.dispatch('getJxhkList', {hosId: this.$route.query.hosId, pageNo: 1, pageSize: 2})
    },
    // banner数据
    hosCourse () {
      this.$store.dispatch('getHosCourse', {hosId: this.$route.query.hosId})
    },
    // 主题系列课
    getThemeList () {
      this.$store.dispatch('getThemeList', {hosId: this.$route.query.hosId, pageNo: this.page, pageSize: 5, vue: this})
    },
    // 上拉加载更多
    loadBottom () {
      let _this = this
      _this.page++
      _this.getThemeList()
      setTimeout(function () {
        _this.$refs.loadmore.onBottomLoaded()
      }, 1000)
    },
    formatDuring (mss) {
      let hours = parseInt((mss % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      let minutes = parseInt((mss % (1000 * 60 * 60)) / (1000 * 60))
      // let seconds = (mss % (1000 * 60)) / 1000
      return hours + '小时' + minutes + '分钟'
    },
    format (date) {
      let time = new Date(date)
      let y = time.getFullYear()
      let m = time.getMonth() + 1
      let d = time.getDate()
      let h = time.getHours()
      let mm = time.getMinutes()
      let s = time.getSeconds()
      return y + '-' + this.judge(m) + '-' + this.judge(d) + ' ' + this.judge(h) + ':' + this.judge(mm) + ':' + this.judge(s)
    },
    judge (m) {
      return m < 10 ? '0' + m : m
    },
    // 查看更多
    cloudClassMore () {
      this.$router.push({path: '/goodcourse?hosId=' + this.$route.query.hosId})
    },
    // 精选好课
    jxhkInfo (row) {
      this.cloudClassSpot({log_type: '3-hos-online-course-click', doctor_id: '', course_id: row.courseId, service_id: ''})
      window.location.href = domain.url + `/#/school/expert-detail?courseId=${row.courseId}`
    },
    // 主题系列课
    themeInfo (row) {
      this.cloudClassSpot({log_type: '3-hos-online-course-click', doctor_id: '', course_id: row.courseId, service_id: ''})
      window.location.href = domain.url + `/#/school/academy-detail?courseId=${row.courseId}`
    },
    // 打点
    cloudClassSpot (row) {
      let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
      this.cloudClassSrc = `https://wifi.bblink.cn/springrx/getWemaPoint?log_type=${row.log_type}&open_id=${openId}&service_id=${row.service_id}&doctor_id=${row.doctor_id}&course_id=${row.course_id}`
    }
  }
}
</script>
<style lang="less" scoped>
#cloudClass {
  .no-data-main {
    text-align: center;
  }
  .no-data {
    width: 240px;
    height: 240px;
    margin-top: 240px;
  }
  .no-data-text {
    color: #888888;
    font-size: 30px;
    margin-top: 32px;
  }
  .bg {
    width: 100%;
    height: 20px;
    background-color: #F2F2F2;
  }
  .banner-main {
    position: relative;
    .banner {
      width: 100%;
      height: 240px;
      vertical-align: bottom;
    }
    .mask {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 240px;
    }
    .banner-info {
      position: absolute;
      left: 20px;
      bottom: 18px;
      color: #FFFFFF;
      .banner-name {
        font-size: 32px;
        height: 36px;
        line-height: 36px;
        margin-bottom: 14px;
      }
      .banner-text {
        font-size: 28px;
        height: 36px;
        line-height: 36px;
      }
    }
  }
  .cloudClass-title {
    display: flex;
    align-items: center;
    margin-left: 20px;
    padding: 38px 0 32px;
    .title-img {
      width: 30px;
      height: 32px;
    }
    .title-name {
      margin-left: 10px;
      font-size: 32px;
    }
  }
  #jxhk {
    .jxhk-main {
      display: flex;
      margin-left: 20px;
      padding-bottom: 30px;
      // border-bottom: 1px solid #dddddd;
      position: relative;
      margin-bottom: 40px;
      &:before {
        content: '';
        width: 200%;
        height: 200%;
        position: absolute;
        top: 0;
        left: 0;
        border-bottom: 1px solid #dddddd; /* no */
        transform: scale(0.5);
        transform-origin: 0 0;
        box-sizing: border-box;
        pointer-events: none;
      }
      .jxhk-img {
        width: 176px;
        height: 176px;
        vertical-align: bottom;
      }
      .jxhk-info {
        margin-left: 24px;
        .jxhk-name {
          width: 510px;
          font-size: 32px;
          height: 32px;
          line-height: 32px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        .doctor-info {
          color: #999999;
          font-size: 28px;
          height: 40px;
          line-height: 40px;
          margin: 12px 0 4px;
          .doctor-name {
            margin-right: 24px;
          }
        }
        .hospital-name {
          height: 34px;
          line-height: 34px;
          color: #999999;
          font-size: 24px;
        }
        .jxhk-btn {
          width: 120px;
          height: 56px;
          margin-top: 6px;
        }
      }
    }
    .jxhk-last {
      margin-bottom: 0px;
    }
    .jxhk-last-b {
      border: 0px;
    }
  }
  .jxhk-more {
    color: #999999;
    font-size: 28px;
    width: 100%;
    height: 80px;
    text-align: center;
    line-height: 80px;
  }
  .label-main {
    display: flex;
    align-items: center;
    height: 32px;
    margin-top: 18px;
    .label-info {
      border: 1px solid #FF7070;
      color: #FF7070;
      text-align: center;
      line-height: 30px;
      border-radius: 8px;
      font-size: 20px;
      display: flex;
      align-items: center;
      .spot {
        width: 10px;
        height: 10px;
        background-color: #FF7070;
        border-radius: 50%;
        margin: 0 4px 0 8px;
      }
      .text {
        height: 28px;
        line-height: 28px;
        padding-top: 4px;
        padding-right: 8px;
      }
    }
    .time-title {
      color: #999999;
      font-size: 22px;
      margin-left: 10px;
    }
    .time {
      color: #FF7070;
      font-size: 22px;
    }
    .live-info {
      display: flex;
      align-items: center;
      font-size: 20px;
      border-radius: 8px;
      background: linear-gradient(to right, #FF62A9, #FF7070);
      .spot {
        width: 10px;
        height: 10px;
        background-color: #FFFFFF;
        border-radius: 50%;
        margin: 0 4px 0 8px;
      }
      .text {
        height: 28px;
        line-height: 28px;
        padding-top: 4px;
        padding-right: 8px;
        color: #FFFFFF;
      }
    }
    .live-time-title {
      color: #FF7070;
      font-size: 22px;
    }
    .live-time-title1 {
      color: #999999;
    }
    .live-time {
      color: #999999;
      font-size: 22px;
    }
    .live-time1 {
      color: #FC575D;
    }
  }
  #theme {
    .theme-img {
      width: 702px;
      height: 338px;
      margin-left: 24px;
      vertical-align: bottom;
    }
    .theme-text {
      font-size: 32px;
      padding: 30px 0 10px;
      margin-left: 24px;
    }
    .theme-main {
      display: flex;
      align-items: center;
      margin-left: 24px;
      // border-bottom: 1px solid #dddddd;
      padding-bottom: 32px;
      margin-bottom: 42px;
      height: 32px;
      position: relative;
      &:before {
        content: '';
        width: 200%;
        height: 200%;
        position: absolute;
        top: 0;
        left: 0;
        border-bottom: 1px solid #dddddd; /* no */
        transform: scale(0.5);
        transform-origin: 0 0;
        box-sizing: border-box;
        pointer-events: none;
      }
      .theme-info {
        border: 1px solid #FF7070;
        color: #FF7070;
        text-align: center;
        line-height: 30px;
        border-radius: 8px;
        font-size: 20px;
        display: flex;
        align-items: center;
        .spot {
          width: 10px;
          height: 10px;
          background-color: #FF7070;
          border-radius: 50%;
          margin: 0 4px 0 8px;
        }
        .text {
          height: 28px;
          line-height: 28px;
          padding-top: 4px;
          padding-right: 8px;
        }
      }
      .time-title {
        color: #999999;
        font-size: 22px;
        margin-left: 10px;
      }
      .time {
        color: #FF7070;
        font-size: 22px;
      }
      .live-info {
        display: flex;
        align-items: center;
        font-size: 20px;
        border-radius: 8px;
        background: linear-gradient(to right, #FF62A9, #FF7070);
        .spot {
          width: 10px;
          height: 10px;
          background-color: #FFFFFF;
          border-radius: 50%;
          margin: 0 4px 0 8px;
        }
        .text {
          height: 28px;
          line-height: 28px;
          padding-top: 4px;
          padding-right: 8px;
          color: #FFFFFF;
        }
      }
      .live-time-title {
        color: #FF7070;
        font-size: 22px;
      }
      .live-time {
        color: #999999;
        font-size: 22px;
      }
    }
    .empty {
      margin-bottom: 42px;
      padding-bottom: 0;
    }
    .theme-last {
      border-bottom: 0px solid #dddddd;
      margin-bottom: 0;
    }
    .jxhk-btn {
      width: 120px;
      height: 56px;
      margin-top: 6px;
    }
  }
  .playback {
    font-size: 22px;
    color: #999999;
    margin-left: 4px;
  }
  .live-text {
    font-size: 22px;
    color: #FF7070;
    // margin-left: 14px;
  }
}
</style>
