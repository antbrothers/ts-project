<template>
  <div class="home-main">
    <div>
      <HosHead :hosd="hosDetail"></HosHead>
    </div>
    <div class="empty"></div>
    <div class="home-nc">
      <div class="head-main">
        <div class="head"></div>
        <div class="title">医院简介</div>
      </div>
      <div class="desc" v-html='hosDetail.intro' ref='desc'>
      </div>
    </div>
    <img :src="aaa" alt="" style="display:none;">
  </div>
</template>
<style lang="less" scoped src='../../../src/assets/less/hospitial.home.less'></style>
<script>
import HosHead from '../hostpital-header/index'
import { mapState } from 'vuex'
export default {
  computed: {
    ...mapState({
      hosDetail: state => state.hosDetail.dt
    })
  },
  components: {
    HosHead
  },
  data () {
    return {
      aaa: '',
      id: ''
    }
  },
  methods: {
    // 获取医院详情
    getHosDetailData () {
      this.$store.dispatch('getHosDetail', {hosId: this.$route.query.hosId, vue: this})
    }
  },
  mounted () {
    // 医院详情 3-hos-info
    let openId = localStorage.getItem('openId') ? localStorage.getItem('openId') : ''
    this.aaa = 'https://wifi.bblink.cn/springrx/getWemaPoint?log_type=3-hos-info&open_id=' + openId + '&service_id=&doctor_id='
    this.getHosDetailData()
  },
  updated () {
    let descChildren = this.$refs.desc.children
    for (let i = 0; i < descChildren.length; i++) {
      descChildren[i].style.width = '100%'
    }
  }
}
</script>
