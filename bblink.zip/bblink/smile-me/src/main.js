// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import Mint from 'mint-ui'
import App from './App'
import router from './router'
import store from './store'
import Plugins from './plugin/global'
import 'mint-ui/lib/style.css'
// import { tool } from './common/util'
// import { domain } from './common/domain'
// import { agent } from './common/useragent'
Vue.config.productionTip = false
Vue.use(Plugins)
Vue.use(Mint)

router.afterEach((to, from, next) => {
  window.scrollTo(0, 0)
})
/* eslint-disable no-new */
router.beforeEach((to, from, next) => {
  /* 路由发生变化修改页面title */
  if (to.meta.title) {
    document.title = to.meta.title
  }
  next()
})
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
