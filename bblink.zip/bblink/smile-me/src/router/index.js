import Vue from 'vue'
import Router from 'vue-router'
// const Home = resolve => {
//   require.ensure(['@/components/welcome/home'], () => {
//     resolve(require('@/components/welcome/home'))
//   }, 'home')
// }
const hospitalHome = resolve => { // 医院主页
  require.ensure(['@/components/hospitalHome/index'], () => {
    resolve(require('@/components/hospitalHome/index'))
  }, 'hospitalHome')
}
const cloudClass = resolve => { // 云课堂
  require.ensure(['@/components/hospitalHome/cloudClass'], () => {
    resolve(require('@/components/hospitalHome/cloudClass'))
  }, 'cloudClass')
}
// const NOTFUND = resolve => { // 404 页面
//   require.ensure(['@/components/NOT/found'], () => {
//     resolve(require('@/components/NOT/found'))
//   }, 'notfound')
// }
const Menzhen = resolve => { // 专病门诊
  require.ensure(['@/components/zhuanbing/menzhen'], () => {
    resolve(require('@/components/zhuanbing/menzhen'))
  }, 'menzhen')
}
const CardDetails = resolve => { // 服务卡详情
  require.ensure(['@/components/cardDetails/cardDetails'], () => {
    resolve(require('@/components/cardDetails/cardDetails'))
  }, 'carddetails')
}
const curriculumDetails = resolve => { // 课程详情
  require.ensure(['@/components/curriculumDetails/curriculumDetails'], () => {
    resolve(require('@/components/curriculumDetails/curriculumDetails'))
  }, 'curriculumdetails')
}
const PregnantWomen = resolve => { // 孕妇学校
  require.ensure(['@/components/pregnantWomen'], () => {
    resolve(require('@/components/pregnantWomen'))
  }, 'pregnantWomen')
}
const DoctorsList = resolve => { // 服务医生列表
  require.ensure(['@/components/doctors/doctorsList'], () => {
    resolve(require('@/components/doctors/doctorsList'))
  }, 'DoctorsList')
}
const MenZhenDoctorList = resolve => { // 门诊医生列表
  require.ensure(['@/components/doctors/menZhenDoctorList'], () => {
    resolve(require('@/components/doctors/menZhenDoctorList'))
  }, 'menZhenDoctorList')
}
const Sweetown = resolve => { // 随堂测试
  require.ensure(['@/components/sweetown/test'], () => {
    resolve(require('@/components/sweetown/test'))
  }, 'sweetown')
}
const Menu = resolve => {
  require.ensure(['@/components/test/menu'], () => {
    resolve(require('@/components/test/menu'))
  }, 'menu')
}
const MyTest = resolve => { // 我的随堂测试
  require.ensure(['@/components/mine/myTest'], () => {
    resolve(require('@/components/mine/myTest'))
  }, 'mytest')
}
const MyRecord = resolve => { // 我的上课记录
  require.ensure(['@/components/mine/myRecord'], () => {
    resolve(require('@/components/mine/myRecord'))
  }, 'myRecord')
}
const goodCourse = resolve => { // 精选好课
  require.ensure(['@/components/googCourse/course'], () => {
    resolve(require('@/components/googCourse/course'))
  }, 'goodCourse')
}
const hospitialDetail = resolve => { // 医院详情
  require.ensure(['@/components/hospitalHome/home'], () => {
    resolve(require('@/components/hospitalHome/home'))
  }, 'hospitialDetail')
}
Vue.use(Router)

export default new Router({
  mode: 'hash',
  // base: '/new',
  routes: [
    {
      path: '/',
      name: 'Home',
      component: hospitalHome,
      meta: {
        title: '医院主页'
      }
    }, {
      path: '*',
      name: '404',
      component: Menu
    }, {
      path: '/menzhen',
      name: 'menzhen',
      component: Menzhen,
      meta: {
        title: '专病门诊'
      }
    }, {
      path: '/cardDetails',
      name: 'cardDetails',
      component: CardDetails,
      meta: {
        title: '服务卡详情'
      }
    }, {
      path: '/hospitalhome',
      name: 'hospitalHome',
      component: hospitalHome,
      meta: {
        title: '医院主页'
      }
    }, {
      path: '/curriculumDetails',
      name: 'curriculumDetails',
      component: curriculumDetails,
      meta: {
        title: '课程详情'
      }
    }, {
      path: '/cloudclass',
      name: 'cloudClass',
      component: cloudClass,
      meta: {
        title: '云课堂'
      }
    }, {
      path: '/doctorslist',
      name: 'doctorslist',
      component: DoctorsList,
      meta: {
        title: '服务医生列表'
      }
    }, {
      path: '/MenZhenDoctor',
      name: 'MenZhenDoctor',
      component: MenZhenDoctorList,
      meta: {
        title: '门诊医生列表'
      }
    }, {
      path: '/menu',
      name: 'Menu',
      component: Menu,
      meta: {
        title: '菜单汇总'
      }
    }, {
      path: '/sweetown',
      name: 'Sweetown',
      component: Sweetown,
      meta: {
        title: '随堂测试'
      }
    }, {
      path: '/goodCourse',
      name: 'goodCourse',
      component: goodCourse,
      meta: {
        title: '精选好课'
      }
    }, {
      path: '/hospitialDetail',
      name: 'hospitialDetail',
      component: hospitialDetail,
      meta: {
        title: '医院详情'
      }
    }, {
      path: '/pregnantwomen',
      name: 'pregnantwomen',
      component: PregnantWomen,
      meta: {
        title: '孕妇学校'
      }
    }, {
      path: '/myTest',
      name: 'myTest',
      component: MyTest,
      meta: {
        title: '我的随堂测试'
      }
    }, {
      path: '/myRecord',
      name: 'myRecord',
      component: MyRecord,
      meta: {
        title: '我的上课记录'
      }
    }
  ]
})
