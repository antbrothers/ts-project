<template>
  <div id="app">
    <div style="height: 100%;width: 100%;">
       <router-view/>
    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex'
export default {
  computed: mapState({
    load: state => state.loading   
  }),
  components: {
  },
  data () {
    return {     
    }
  },
  methods: {   
  },
  mounted () {   
  }
}
</script>
<style>
body,
html {
  height: 100%;
  width: 100%;
  margin: 0px;
  font-family:PingFangSC-Regular;
}
#app {
  height: 100%;
  width: 100%;
}
.header-comm{
  background:rgba(249,249,249,1);
  color: white; 
  color:#333333;
  font-size:36px; /* px */
  letter-spacing: 3px;
}
</style>
