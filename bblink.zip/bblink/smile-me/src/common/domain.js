var domain = {
  url: process.env.NODE_ENV === 'production' ? 'https://www.wemami.com' : 'https://ffuer.uneedme.cn',
  root: process.env.NODE_ENV === 'production' ? 'https://api.uneedme.cn' : 'https://fapi.uneedme.cn', // 微信授权
  appId: process.env.NODE_ENV === 'production' ? 'wxcf0b597a201e491e' : 'wx5fbc1df873478202'
}
module.exports = {
  domain
}
