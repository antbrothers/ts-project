import axios from 'axios'
// import cookie from 'js-cookie'
import { tool } from '../common/util'
import { agent } from '../common/useragent'
import { domain } from '../common/domain'
export function fetch (options, _this) {
  return new Promise((resolve, reject) => {
    if (_this) {
      _this.$store.dispatch('loadingState', { load: true })
    }
    // var bblinktoken = cookie.get('bblinktoken') ? JSON.parse(cookie.get('bblinktoken')) : ''
    const instance = axios.create({
      headers: {
        'Content-Type': options.responseType ? options.responseType : 'application/json',
        bblinkToken: tool.localStorage.get('bblinkToken') || ''
        //  bblinkToken: 'tokenv1:MzE2MGVjM2U1YTZkNDk3NDhiN2FiNzdlMTAyNDBjNTUxNTMyNjcyMDMwMzMw'
      },
      timeout: 30 * 1000 // 设置30秒超时
    })
    instance(options)
      .then(response => {
        if (!response.data.code) {
          resolve(response)
          options.success(response)
        } else if (response.data.code.indexOf('9002') > -1) {
          // token失效
          if (tool.localStorage.get('bblinkToken')) {
            tool.localStorage.remove('bblinkToken')
          }
          setTimeout(() => {
            tool.localStorage.set('gotoUrl', location.href.split('#')[1])
            if (agent.weChat) {
              var redirectUrl = location.protocol + '//' + location.host + '/' + '#/login/binding-login'
              if (!tool.localStorage.get('openId')) {
                return (location.href = domain.root + '/User/auth?redirect_uri=' + encodeURIComponent(redirectUrl))
              } else {
                return (location.href = location.protocol + '//' + location.host + '/' + '#/login/binding-login')
              }
            } else {
              return (location.href = location.protocol + '//' + location.host + '/' + '#/login')
            }
          }, 1000)
        } else if (response.data.code.indexOf('0000') > -1) {
          resolve(response)
          options.success(response)
        } else if (response.data.code.indexOf('4001') > -1) {
          resolve(response)
          options.success(response)
        } else {
          window.$global_this.$toast({
            message: response.data.msg,
            position: 'bottom',
            duration: 3000
          })
        }
        if (_this) {
          _this.$store.dispatch('loadingState', { load: false })
        }
      })
      .catch(error => {
        console.log('请求异常信息:' + error)
        window.$global_this.$toast({
          message: error.message,
          position: 'bottom',
          duration: 3000
        })
        if (_this) {
          _this.$store.dispatch('loadingState', { load: false })
        }
        reject(error)
      })
  })
}
